<?php
	include_once 'includes/dbh.inc.php';
    session_start();
    
    //$id=$_SESSION["ak"];
    $name = $_POST['pname'];
    $type = $_POST['ptype'];
    $price = $_POST['pprice'];
	$quantity = $_POST['pquantity'];
	$forwhich = $_POST['pfor'];
	$description = $_POST['pdescription'];
    
    //declaring variables
    $filename = $_FILES['image']['name'];
    $filetmpname = $_FILES['image']['tmp_name'];
    //folder where images will be uploaded
    $folder = 'images/products/';
    //function for saving the uploaded images in a specific folder
    copy($_FILES['image']['tmp_name'], $folder.$filename);    

	$sql = "INSERT INTO pet_products (name, type, price, quantity, description, ForWhich, image) VALUES ('$name', '$type', '$price', $quantity, '$description', '$forwhich', '$filename')";
	mysqli_query($conn, $sql);
	header("Location: product_list.php");
?>
