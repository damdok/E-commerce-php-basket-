<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "SELECT * from products4 where productid='".$id."'"; 
$result = mysqli_query($conn, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Product Approval</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="page-extras.php">Dashboard</a> 
| <a href="includes/logout.inc.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$productName =$_REQUEST['productName'];
$quantity =$_REQUEST['quantity'];
$productprice =$_REQUEST['productprice'];
$type =$_REQUEST['type'];
$vNumber=$_REQUEST['vNumber'];
$img=$_REQUEST['img'];
//INSERT INTO animals2 (Type, Name, Breed, Sex, DOB, Color, Size, img, dcNumber) VALUES ('$type', '$id', '$breed', '$sex', '$DOB', '$color', '$size', '$filename', '$dcNumber');
$update="INSERT INTO products (productprice, quantity, type, productName, img, vNumber) VALUES ('$productprice', '$quantity', '$type', '$productName', '$img', '$vNumber');";
mysqli_query($conn, $update) or die(mysqli_error());
$query = "DELETE from products4 where productid='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
$status = "Product Succesfully Added. </br></br>
<a href='productreview.php'>View Remaining Requests</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<center><form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['productid'];?>" />
<p><input type="text" name="productName" placeholder="Enter Name" 
required value="<?php echo $row['productName'];?>" /></p>
<p><input type="text" name="productprice" placeholder="Enter Product Price" 
required value="<?php echo $row['productprice'];?>" /></p>
<p><input type="text" name="quantity" placeholder="Enter Quantity" 
required value="<?php echo $row['quantity'];?>" /></p>
<p><input type="text" name="type" placeholder="Enter Type" 
required value="<?php echo $row['type'];?>" /></p>
<p><input type="text" name="vNumber" placeholder="Enter vNumber" 
required value="<?php echo $row['vNumber'];?>" /></p>
<p><input type="text" name="img" placeholder="Enter Image" 
required value="<?php echo $row['img'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form></center>
<?php } ?>
</div>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>