<?php
	include_once 'dbh.inc.php';

	$idAnimal = $_POST['idAnimal'];
	$Type = $_POST['Type'];
	$Name = $_POST['Name'];
	$Breed = $_POST['Breed'];
    $Sex = $_POST['Sex'];
    $Age = $_POST['Age'];
    $Color = $_POST['Color'];
    $Size = $_POST['Size'];
    $description = $_POST['Description'];

	$sql = "INSERT INTO animals  (idAnimal, Type, Name, Breed, Sex, Age, Color, Size, Description) VALUES ('$idAnimal', '$Type', '$Name', '$Breed', '$Sex', '$Age', 'Color', '$Size', '$Description');";
	mysqli_query($conn, $sql);
	header("Location: ../index.php?addProduct=success");
