<?php
	include_once 'dbh.inc.php';
    session_start();
    
    $id=$_SESSION["ak"];
	$pname = $_POST['pname'];
	$quantity = $_POST['quantity'];
	$description = $_POST['description'];
	$productprice = $_POST['price'];
    $type = $_POST['type'];
    
    //declaring variables
    $filename = $_FILES['image']['name'];
    $filetmpname = $_FILES['image']['tmp_name'];
    //folder where images will be uploaded
    $folder = '../images/products/';
    //function for saving the uploaded images in a specific folder
    copy($_FILES['image']['tmp_name'], $folder.$filename);
    

	$sql = "INSERT INTO products4 (productprice, productName, quantity, type, img, vNumber) VALUES ('$productprice', '$pname', '$quantity', '$type', '$filename', '$id');";
	mysqli_query($conn, $sql);
	header("Location: ../index.php?addProduct=success");
