<?php
// Here we check whether the user got to this page by clicking the proper signup button.
if (isset($_POST['signup-submit'])) {

  require 'dbh.inc.php';

  $productname = $_POST['pname'];
  $partnumber = $_POST['partnum'];
  $quantity = $_POST['quantity'];
  $description = $_POST['description'];
  $type = $_POST['type'];


  // check for any empty inputs. (PS: This is where most people get errors because of typos! Check that your code is identical to mine. Including missing parenthesis!)
  if (empty($productname) || empty($partnumber) || empty($quantity) || empty($description)) {
    header("Location: ../signup.php?error=emptyfields&uid=".$productname."&mail=".$partnumber);
    exit();
  }
  // check for an invalid productname AND invalid e-mail.
  else if (!preg_match("/^[a-zA-Z0-9]*$/", $productname) && !filter_var($partnumber, FILTER_VALIDATE_partnumber)) {
    header("Location: ../signup.php?error=invaliduidmail");
    exit();
  }
  // check for an invalid productname. In this case ONLY letters and numbers.
  else if (!preg_match("/^[a-zA-Z0-9]*$/", $productname)) {
    header("Location: ../signup.php?error=invaliduid&mail=".$partnumber);
    exit();
  }
  // check for an invalid e-mail.
  else if (!preg_match("/^[a-zA-Z0-9]*$/",$partnumber)) {
    header("Location: ../signup.php?error=invalidmail&uid=".$productnumber);
    exit();
  }
  
  else {


    $sql = "SELECT productname FROM users WHERE productname=?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
      header("Location: ../signup.php?error=sqlerror");
      exit();
    }
    else {
      mysqli_stmt_bind_param($stmt, "s", $productname);
      mysqli_stmt_execute($stmt);
      mysqli_stmt_store_result($stmt);
      $resultCount = mysqli_stmt_num_rows($stmt);
      mysqli_stmt_close($stmt);
      if ($resultCount > 0) {
        header("Location: ../signup.php?error=usertaken&mail=".$partnumber);
        exit();
      }
      else {


        $sql = "INSERT INTO users (productid, productprice, quantity, description, type) VALUES (?, ?, ?, ?, ?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
          header("Location: ../signup.php?error=sqlerror");
          exit();
        }
        else {

        }
      }
    }
  }
  mysqli_stmt_close($stmt);
  mysqli_close($conn);
}
else {
  header("Location: ../addprouct.php");
  exit();
}
