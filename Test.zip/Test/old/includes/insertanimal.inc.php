<?php
	include_once 'dbh.inc.php';
	session_start();
    
    $id=$_SESSION["ak"];
	$idAnimal = $_POST['idAnimal'];
	$Type = $_POST['Type'];
	$Breed = $_POST['Breed'];
    $Sex = $_POST['Sex'];
    $DOB = $_POST['DOB'];
    $Color = $_POST['Color'];
    $Size = $_POST['Size'];
    $description = $_POST['Description'];
    
    //declaring variables
    $filename = $_FILES['image']['name'];
    $filetmpname = $_FILES['image']['tmp_name'];
    //folder where images will be uploaded
    $folder = '../images/pets/';
    //function for saving the uploaded images in a specific folder
    copy($_FILES['image']['tmp_name'], $folder.$filename);
    

	$sql = "INSERT INTO animals2 (Type, Name, Breed, Sex, DOB, Color, Size, Description, img, dcNumber) VALUES ('$Type', '$idAnimal', '$Breed', '$Sex', '$DOB', '$Color', '$Size', '$description', '$filename', '$id');";
	mysqli_query($conn, $sql);
	header("Location: ../index.php?addProduct=success");
