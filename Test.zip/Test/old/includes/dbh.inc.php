<?php
$dBServername = "localhost";
$dBUsername = "ihdewjlu_users";
$dBPassword = "PFpass1";
$dBName = "ihdewjlu_users";

// Create connection
$conn = mysqli_connect($dBServername, $dBUsername, $dBPassword, $dBName);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
