<div id="sidebar" >
	<aside id="socnets_wrap" class="clearfix">
		<div id="socnets">
			<a href="#" title="Twitter" class="socnet-twitter"></a>
			<a href="#" title="Facebook" class="socnet-facebook"></a>
			<a href="#" title="Google+" class="socnet-google"></a>
		</div>
	</aside>
	<?php if ($page_file_name != "index.php") { ?>
	
	<?php } ?>
	<aside class="widget">
	
			<script type='text/javascript' src='http://maps.google.com/maps/api/js?sensor=false&#038;ver=3.9.1'></script>
			<div class="pw_map_canvas" id="dcs_map_rescue" style="height: 200px; width: 100%"></div>
			<script type="text/javascript">
			var rescue_map;
			function pw_run_rescue_map(){
				var location = new google.maps.LatLng("40.752353", "-73.428157");
				var map_options = {
					zoom: 15,
					center: location,
					mapTypeId: google.maps.MapTypeId.ROADMAP
				}
				rescue_map = new google.maps.Map(document.getElementById("dcs_map_rescue"), map_options);
				var marker = new google.maps.Marker({
					position: location,
					map: rescue_map
				});
			}
			pw_run_rescue_map();
			</script>
		</div>
	</aside>
</div>