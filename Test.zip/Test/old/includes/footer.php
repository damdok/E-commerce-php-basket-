				</div><?php // end div.container, begins in header.php ?>
			</section><?php // end #main_content, begins in header.php ?>
			<footer id="footer" class="wrapper">
				<div class="container">
					
					<div id="post_footer">
						<div id="site_info" class="clearfix">
							<div class="left footer_menu_wrap clearfix">
								<div class="menu-footer-menu-container">
									<ul id="menu-footer-menu" class="menu">
										<li><a href="index.php">Home</a></li>
										<li><a href="pets-all.php">FAQ</a></li>
										<li><a href="page-full.php">Support</a></li>
										<li><a href="blog.php">Blog</a></li>
										<li><a href="page-contact.php">Contact Us</a></li>
									</ul>
								</div>
							</div>
							<div class="right">
								&copy; <?php echo date("Y"); ?> Pet Detector <span class="site_info_space"></span>
								<span class="site_info_bloginfo">
									<a href="http://themes.designcrumbs.com" title="Rescue Template"></a><a href="http://designcrumbs.com" title="Design Crumbs"></a>
								</span>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</section><?php // end div#main_wrap, begins in header.php ?>
		<?php // jQuery We Need ?>
		<script type="text/javascript" src="includes/js/jquery-1.11.1.min.js"></script>
		<script type="text/javascript" src="includes/fancybox/jquery.fancybox.js"></script>
		<!-- <script type="text/javascript" src="includes/js/jquery.sticky.js"></script> // uncomment this to use the sticky header -->
		<script type="text/javascript" src="includes/js/jquery.flexslider-min.js"></script>
		<script type="text/javascript" src="includes/js/jquery.mobilemenu.js"></script>
		<script type="text/javascript" src="includes/js/rescue.js"></script>
	</body>
</html>