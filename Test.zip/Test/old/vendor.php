<?php include('header.php'); ?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Vendor Homepage</h2>
		<div class="clearfix">
			<div class="entry-content clearfix">
				<p>
                <form action="addproduct.php">
                    <input type="submit" value="Add New Item to the Store" />
                </form>
                <br><br>
                <form action="productlisting.php">
                    <input type="submit" value="View/Update Products Listed" />
                </form>
				</p>
			</div>
		</div>


<?php include('includes/footer.php'); ?>