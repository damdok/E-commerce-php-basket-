<?php
if (isset($_POST)) {

  require 'includes/dbh.inc.php';
  
  $uid = $_POST['uid'];
  $pid = $_POST['pid'];

  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];
  $date = $_POST['date'];
   $time = $_POST['time'];

   
  $query = mysqli_query($conn , " INSERT INTO `appointment` (`id`, `uid`, `pid`, `name`, `phone`, `email`, `date`, `time`) VALUES (NULL, '".$uid."', '".$pid."', '".$name."', '".$phone."', '".$email."', '".$date."', '".$time."'); ");
 
  $msg = "Hi,

Your Request has been successfully submitted. We will reply you asap.

Regards
Pet Finder
";


// send email
mail($email,"Pet finder appoitment request",$msg);

   header("Location: bookappointment.php?status=1");
          exit();
}
