<?php include('header.php'); ?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Different Breed</h2>
		<div class="clearfix">
			<div class="entry-content clearfix">
				<p>
				</p>
			</div>
		</div>
		<section id="all_pets_wrap">
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="https://en.wikipedia.org/wiki/Dog">
						<img width="275" height="275" src="images/pets/archie1-275x275.jpg" class="attachment-pet_single_large" alt="Archie" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="https://en.wikipedia.org/wiki/Dog" title="Archie">Dogs</a></h2>
			</article>
           <article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="https://en.wikipedia.org/wiki/Cat">
						<img width="275" height="275" src="images/pets/happy1-275x275.jpg" class="attachment-pet_single_large" alt="happy1" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Cats">Cats</a></h2>
				
			</article>
            <article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="https://en.wikipedia.org/wiki/Exotic_pet">
						<img width="275" height="275" src="images/pets/exoticAnimals.jpg" class="attachment-pet_single_large" alt="happy1" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="https://en.wikipedia.org/wiki/Exotic_pet" title="Exotic">Exotic</a></h2>
				
			</article>


<?php include('includes/sidebar.php'); ?>

<?php include('includes/footer.php'); ?>
