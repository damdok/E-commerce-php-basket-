<?php include('header.php'); ?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Animal Type / Breed</h2>
		<div class="clearfix">
			<div class="entry-content clearfix">
				<p>
				</p>
			</div>
		</div>
		<section id="all_pets_wrap">
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/archie1-275x275.jpg" class="attachment-pet_single_large" alt="Archie" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Archie">Archie</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Border Collie</a> - Young - Male
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Large</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
						<span>Prefers No Cats</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/candy1-275x275.jpeg" class="attachment-pet_single_large" alt="Candy" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Candy">Candy</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Maltese</a> - Baby - Female
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Small</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
						<span>Prefers No Dogs</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/chance1-275x275.jpg" class="attachment-pet_single_large" alt="Chance" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Chance">Chance</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Weimaraner</a> - Baby - Male
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Small</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/charlie-275x275.jpg" class="attachment-pet_single_large" alt="Charlie" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Charlie">Charlie</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Basque Shepherd Dog</a> - Young - Male
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Large</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/chester2-275x275.jpg" class="attachment-pet_single_large" alt="chester2" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Chester">Chester</a></h2>
					<div class="breed">
						<a href="pets-animal.php">American Shorthair</a> - <a href="pets-animal.php">Tuxedo</a> -
						Adult -
						Male
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Medium</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
						<span>Special Needs</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/cindy1-275x275.jpg" class="attachment-pet_single_large" alt="Cindy" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Cinderella">Cinderella</a></h2>
					<div class="breed">
						<a href="pets-animal.php">American Shorthair</a> - <a href="pets-animal.php">Calico</a> - Adult - Female
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Large</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/grissom1-275x275.jpg" class="attachment-pet_single_large" alt="IMG_0095 4" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Grissom">Grissom</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Border Collie</a> - Adult - Male
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Extra Large</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
						<span>Prefers No Cats</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/happy1-275x275.jpg" class="attachment-pet_single_large" alt="happy1" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Happy">Happy</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Calico</a> - <a href="pets-animal.php">Domestic Longhair</a> - Adult - Female
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Medium</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/inga1-275x275.jpg" class="attachment-pet_single_large" alt="inga" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Inga">Inga</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Golden Retreiver</a> - Young - Female
					</div>
					<div class="pet_info clearfix">
						<span>Adoptable</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
						<span>Prefers No Cats</span>
						<span>Prefers No Dogs</span>
						<span>Prefers No Kids</span>
					</div>
				</div>
			</article>
			<article class="rescue_pet">
				<div class="entry-content clearfix">
					<a href="pets-single.php">
						<img width="275" height="275" src="images/pets/JazzyGirlAverill-4-275x275.jpg" class="attachment-pet_single_large" alt="JazzyGirlAverill-4" />
					</a>
					<h2 class="entry-title pet-name-title"><a href="pets-single.php" title="Jazzy Girl">Jazzy Girl</a></h2>
					<div class="breed">
						<a href="pets-animal.php">Shar-Pei</a> - Adult - Female
					</div>
					<div class="pet_info clearfix">
						<span class="ex">Adoption Pending</span>
						<span>Large</span>
						<span>Spayed/Neutered</span>
						<span>Up-to-date with routine shots</span>
						<span>House trained</span>
						<span>Prefers No Cats</span>
					</div>
				</div>
			</article>
			<div class="navigation clearfix">
				<div class="nav-prev"><a href="#">&larr; Older Entries</a></div>
				<div class="nav-next"><a href="#">Newer Entries &rarr;</a></div>
			</div>
		</section>
	</section>
</div>

<?php include('includes/sidebar.php'); ?>				
<?php include('includes/footer.php'); ?>