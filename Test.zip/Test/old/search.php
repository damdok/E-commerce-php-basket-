<?php
	include_once'header.php';
?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Search Animal</h2>
		<div class="tab-main">
		  <input id="tab1" type="radio" name="tabs" checked="">
		  <label class="tabs" for="tab1"><strong></strong></label>

		 
		  <div class="content">
			<div id="content1">
				<form action="search.php" method="GET">
					<input type="hidden" name="animal" value="dog"/>
					<div class="grid">
						<div class="row">
                        <div class="col">
								Type<label class="custom-select">
									<select class="custom-select" name="type">
										<option value="">Please Select</option>
										<option value="Dog" <?php if($_GET['type'] == 'Dog'){?> selected <?php } ?> >Dog</option>
										<option value="Cat" <?php if($_GET['type'] == 'Cat'){?> selected <?php } ?> >Cat</option>
									</select>
								</label>
							</div>


							<div class="col">
								BREED<label class="custom-select">
									<select class="custom-select" name="breed">
										<option value="" >All</option>	
										<option value="American Curl" <?php if($_GET[''] == 'American Curl'){?> selected <?php } ?> >American Curl</option>
										<option value="Calico" <?php if($_GET['breed'] == 'Calico'){?> selected <?php } ?> >Calico</option>
										<option value="Hound" <?php if($_GET['breed'] == 'Hound'){?> selected <?php } ?> >Hound</option>
										<option value="Poodle" <?php if($_GET['breed'] == 'Poodle'){?> selected <?php } ?> >Poodle</option>
										<option value="Terrier" <?php if($_GET['breed'] == 'Terrier'){?> selected <?php } ?> >Terrier</option>
                                        <option value="Boxer" <?php if($_GET['breed'] == 'Boxer'){?> selected <?php } ?> >Boxer</option>
                                        <option value="Affenpinscher" <?php if($_GET['breed'] == 'Affenpinscher'){?> selected <?php } ?> >Affenpinscher</option> 
										<option value="Akita" <?php if($_GET['breed'] == 'Akita'){?> selected <?php } ?> >Akita</option>
                                        <option value="Beagle" <?php if($_GET['breed'] == 'Beagle'){?> selected <?php } ?> >Beagle</option>
									
									</select>
								</label>
							</div>
							<div class="col">
								SEX<label class="custom-select">
									<select class="custom-select"  name="sex">
										<option value="">All</option>
										<option value="Female" <?php if($_GET['sex'] == 'Female'){?> selected <?php } ?> >Female</option>
										<option value="Male" <?php if($_GET['sex'] == 'Male'){?> selected <?php } ?> >Male</option>
									</select>
								</label>
							</div>
							<div class="col">
								AGE<label class="custom-select">
									<select class="custom-select" name="age">
										<option value="">All</option>
										<option value="1" <?php if($_GET['age'] == '1'){?> selected <?php } ?> >1 month</option>
										<option value="2" <?php if($_GET['age'] == '2'){?> selected <?php } ?> >2 months</option>
										<option value="3" <?php if($_GET['age'] == '3'){?> selected <?php } ?> >3 months</option>
										<option value="4" <?php if($_GET['age'] == '4'){?> selected <?php } ?> >4 months</option>
										<option value="5" <?php if($_GET['age'] == '5'){?> selected <?php } ?> >5 months</option>
										<option value="6" <?php if($_GET['age'] == '6'){?> selected <?php } ?> >6 months</option>
										<option value="7" <?php if($_GET['age'] == '7'){?> selected <?php } ?> >7 months</option>
										<option value="8" <?php if($_GET['age'] == '8'){?> selected <?php } ?> >8 months</option>
										<option value="9" <?php if($_GET['age'] == '9'){?> selected <?php } ?> >9 months</option>
										<option value="10" <?php if($_GET['age'] == '10'){?> selected <?php } ?> >10 months</option>
										<option value="11" <?php if($_GET['age'] == '11'){?> selected <?php } ?> >11 months</option>
										
										<option value="12" <?php if($_GET['age'] == '12'){?> selected <?php } ?> >1 year</option>
										<option value="24" <?php if($_GET['age'] == '24'){?> selected <?php } ?> >2 years</option>
										<option value="36" <?php if($_GET['age'] == '36'){?> selected <?php } ?> >3 years</option>
										<option value="48" <?php if($_GET['age'] == '48'){?> selected <?php } ?> >4 years</option>
										<option value="60" <?php if($_GET['age'] == '60'){?> selected <?php } ?> >5 years</option>
										<option value="72" <?php if($_GET['age'] == '72'){?> selected <?php } ?> >6 years</option>
										<option value="84" <?php if($_GET['age'] == '84'){?> selected <?php } ?> >7 years</option>
										<option value="96" <?php if($_GET['age'] == '96'){?> selected <?php } ?> >8 years</option>
										<option value="108" <?php if($_GET['age'] == '108'){?> selected <?php } ?> >9 years</option>
										<option value="120" <?php if($_GET['age'] == '120'){?> selected <?php } ?> >10 years</option>
									
									</select>
								</label>
							</div>
						</div>
						<div class="row">
							<div class="col">
								COLOR<label class="custom-select">
									<select class="custom-select" name="color">
										<option value="">All</option>
										<option value="Brown" <?php if($_GET['color'] == 'Brown'){?> selected <?php } ?> >Brown</option>
									
										<option value="Yellow" <?php if($_GET['color'] == 'Yellow'){?> selected <?php } ?> >Yellow</option>
									
										<option value="White" <?php if($_GET['color'] == 'White'){?> selected <?php } ?> >White</option>
										<option value="Black" <?php if($_GET['color'] == 'Black'){?> selected <?php } ?> >Black</option>
									
									</select>
								</label>
							</div>
							<div class="col">
								SIZE<label class="custom-select">
									<select class="custom-select" name="size">
										<option value="">All</option>
										
										
										<option value="Medium" <?php if($_GET['size'] == 'Medium'){?> selected <?php } ?> >Medium</option>
                                        <option value="Small" <?php if($_GET['size'] == 'Small'){?> selected <?php } ?> >Small</option>
										<option value="Large" <?php if($_GET['size'] == 'Large'){?> selected <?php } ?> >Large</option>
									
									</select>
								</label>
							</div>
							<div class="col v-align-btm">
								<button class="grid-btn">Search</button>
							</div>
						</div>
					</div>
				</form>
			</div>
            
			<div id="content2">
				<p>Content for Cat</p>
			</div>

			<div id="content3">
				<p>Content for Pets with special needs</p>
			</div>
		  </div>
		</div>
	</section>



		<div class="posts-wrap">
	<section id="home_latest_posts" class="clearfix">
    <?php 
    $sql = "select * from animals where idAnimal != '' ";
    if($_GET['type'] != ''){  $sql .= " and Type = '".$_GET['type'] ."' ";    }
      if($_GET['breed'] != ''){  $sql .= " and Breed = '".$_GET['breed'] ."' ";    }
      if($_GET['sex'] != ''){  $sql .= " and Sex = '".$_GET['sex'] ."' ";    }
      if($_GET['age'] != ''){  $sql .= " and Age = '".$_GET['age'] ."' ";    }
      if($_GET['color'] != ''){  $sql .= " and Color = '".$_GET['color'] ."' ";    }
      if($_GET['size'] != ''){  $sql .= " and Size = '".$_GET['size'] ."' ";    }
    
  
    
    $query = mysqli_query($conn, $sql);
		
		
		while($data = mysqli_fetch_assoc($query)){ ?>
		
		<article class="single_latest">
			<a href="blog-single.php?id=<?php echo $data['idAnimal']; ?>" title="Meet Cindy" class="single_latest_img_link">
				<img width="275" height="110" src="images/pets/<?php echo $data['img']; ?>" class="attachment-single_latest" alt="Meet Cindy" />
			</a>
			<a href="blog-single.php?id=<?php echo $data['idAnimal']; ?>">	<h2 style="padding:0px;margin:5px;"><?php echo $data['Name']; ?></h2>
            <h4><?php if($data['Age'] < 12){ echo $data['Age']." Month";} else{  $age = $data['Age']/12; echo $age." Year"; } ?>, <?php echo $data['Sex']; ?></h4>
            </a>
			
			<p>
			</p>
			</article>
		<?php } ?>
        </section> </div>
	
</div>
<?php 
	include_once('includes/sidebar.php');
	include_once('includes/footer.php');
?>


