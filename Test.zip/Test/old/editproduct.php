<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "SELECT * from products where productid='".$id."'"; 
$result = mysqli_query($conn, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Update Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="productlisting.php">Dashboard</a> 
| <a href="addproduct.php">Insert Item Into Store</a> 
| <a href="includes/logout.inc.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$name =$_REQUEST['name'];
$quantity =$_REQUEST['quantity'];
$productprice =$_REQUEST['productprice'];
$type =$_REQUEST['type'];
$update="update products set productName='".$name."', productprice='".$productprice."', quantity='".$quantity."', type='".$type."' where productid='$id'";
mysqli_query($conn, $update) or die(mysqli_error());
$status = "Record Updated Successfully. </br></br>
<a href='adminprodlisting.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<center><form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['productid'];?>" />
<p><input type="text" name="name" placeholder="Enter Name" 
required value="<?php echo $row['productName'];?>" /></p>
<p><input type="text" name="productprice" placeholder="Enter Product Price" 
required value="<?php echo $row['productprice'];?>" /></p>
<p><input type="text" name="quantity" placeholder="Enter Quantity" 
required value="<?php echo $row['quantity'];?>" /></p>

<p><input type="text" name="type" placeholder="Enter Type" 
required value="<?php echo $row['type'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form></center>
<?php } ?>
</div>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>