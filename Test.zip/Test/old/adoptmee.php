<?php
 include_once 'includes/dbh.inc.php';
    session_start();
    
if (isset($_POST)) {

 // require 'includes/dbh.inc.php';
  
  $uid = $_SESSION["id"];
  $pid = $_POST['pid'];

  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];
  $why = $_POST['why'];
   $when = $_POST['when'];
   $anName = $_POST['anName'];

   
  $query = mysqli_query($conn , " INSERT INTO `adopt` (`id`, `uid`, `pid`, `name`, `phone`, `address`, `why`, `whenn`) VALUES (NULL, '".$uid."', '".$pid."', '".$name."', '".$phone."', '".$address."', '".$anName."', '".$when."'); ");
 
   header("Location: adoptme.php?status=1");
          exit();
}
