<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script>
    function clicked() {
    return confirm('Approve User For Adoption?');
}</script>
<script>
    function clicked2() {
    return confirm('Are you sure you want to reject this users request?');
}</script>
<title>Adoption Requests</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="user.php">Home</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<h2>Adoption Requests</h2>
<table width="100%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>#</strong></th>
<th><strong>Name</strong></th>
<th><strong>Phone</strong></th>
<th><strong>Address</strong></th>
<th><strong>Who</strong></th>
<th><strong>When</strong></th>
<th><strong>Approve</strong></th>
<th><strong>Cancel</strong></th>
</tr>
</thead>
<tbody>
<?php


//function prompt($prompt_msg){
//        echo("<script type='text/javascript'> var answer = prompt('".$prompt_msg."'); </script>");
//
//        $answer = "<script type='text/javascript'> document.write(parseInt(answer); </script>";
//        return($answer);
//    }

//    //program
//    $prompt_msg = "Please type your name.";
//    $name = prompt($prompt_msg);
//WHERE dcNumber='".$name."' 
$count=1;

$id=$_SESSION["id"];
$sel_query="Select * from adopt WHERE status = '0' Order By id asc";


$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["phone"]; ?></td>
<td align="center"><?php echo $row["address"]; ?></td>
<td align="center"><?php echo $row["why"]; ?></td>
<td align="center"><?php echo $row["whenn"]; ?></td>
<td align="center">
<a href="approvedadopt.php?id=<?php echo $row["id"]; ?>" onclick="return clicked();">Approve</a>
</td>
<td align="center">
<a href="admindeleteadopt.php?id=<?php echo $row["id"]; ?>" onclick="return clicked2();">Cancel</a>
</td>

</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>