<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "SELECT * from animals2 where idAnimal='".$id."'"; 
$result = mysqli_query($conn, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Animal Adoption Approval</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="page-extras.php">Dashboard</a> 
| <a href="includes/logout.inc.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$name =$_REQUEST['name'];
$DOB =$_REQUEST['DOB'];
$breed =$_REQUEST['breed'];
$dcNumber =$_REQUEST['dcNumber'];
$filename =$_REQUEST['filename'];
$type =$_REQUEST['type'];
$sex =$_REQUEST['sex'];
$color =$_REQUEST['color'];
$size =$_REQUEST['size'];
//INSERT INTO animals2 (Type, Name, Breed, Sex, DOB, Color, Size, img, dcNumber) VALUES ('$type', '$id', '$breed', '$sex', '$DOB', '$color', '$size', '$filename', '$dcNumber');
$update="INSERT INTO animals (Type, Name, Breed, Sex, DOB, Color, Size, img, dcNumber) VALUES ('$type', '$name', '$breed', '$sex', '$DOB', '$color', '$size', '$filename', '$dcNumber');";
mysqli_query($conn, $update) or die(mysqli_error());
$query = "DELETE from animals2 where idAnimal='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
$status = "Animal Successfully Added. </br></br>
<a href='adminreview.php'>View Remaining Requests</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<center><form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['idAnimal'];?>" />
<p><input type="text" name="name" placeholder="Enter Name" 
required value="<?php echo $row['Name'];?>" /></p>
<p><input type="date" name="DOB" placeholder="Enter Date of Birth" 
required value="<?php echo $row['DOB'];?>" /></p>
<p><input type="text" name="breed" placeholder="Enter Breed" 
required value="<?php echo $row['Breed'];?>" /></p>
<p><input type="text" name="type" placeholder="Enter Type" 
required value="<?php echo $row['Type'];?>" /></p>
<p><input type="text" name="sex" placeholder="Enter Sex" 
required value="<?php echo $row['Sex'];?>" /></p>
<p><input type="text" name="color" placeholder="Enter Color" 
required value="<?php echo $row['Color'];?>" /></p>
<p><input type="text" name="size" placeholder="Enter Size" 
required value="<?php echo $row['Size'];?>" /></p>
<p><input type="text" name="dcNumber" placeholder="Enter dcNumber" 
required value="<?php echo $row['dcNumber'];?>" /></p>
<p><input type="text" name="filename" placeholder="Enter filename" 
required value="<?php echo $row['img'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form></center>
<?php } ?>
</div>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>