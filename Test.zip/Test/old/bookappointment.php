<?php
session_start();
error_reporting(0);

if($_SESSION['id'] == ''){
	header('Location: signup.php');
	
	
}
  // To make sure we don't need to create the header section of the website on multiple pages, we instead create the header HTML markup in a separate file which we then attach to the top of every HTML page on our website. In this way if we need to make a small change to our header we just need to do it in one place. This is a VERY cool feature in PHP!
  require "header.php";
  $pet = mysqli_query($conn,"select * from animals where idAnimal = '".$_GET['id']."' ");
  $pdata = mysqli_fetch_assoc($pet);
  
  
?>

    <main>
      <div class="wrapper-main">
        <section class="section-default">
	   <?php if($_GET['id'] != ''){ ?>	<img width="100"  src="images/pets/<?php echo $pdata['img']; ?>" class="attachment-big_latest" alt="Meet Cindy" style="float:left;" />
		<br><br><br>
				
          <h1 style="float:left;">Book Appointment for  <?php echo $pdata['Name']; ?></h1>
		  <br><br><br><br><br>
		  <p>Apointment Request Form:</p>
		  
		  <?php } if (isset($_GET["status"])) {
            if ($_GET["status"] == "1") {
              echo '<p class="signupsuccess" style="text-align:left;">Adoption Request successful!</p>';
            }
          }
		  ?>
        <?php if($_GET['id'] != ''){ ?>
          <form  action="bookappointmentt.php" method="post">
          
		  
		   <input type="hidden" value="<?php echo $_SESSION['id'];?>" name="uid" placeholder="Name" style="width:50%;" required>
		   <br>
            <input type="hidden" value="<?php echo $_GET['id'];?>" name="pid" placeholder="Phone no" required>
            <br><br>
			 
			 
		  
			 <input type="text" name="name" placeholder="Name" style="width:50%;" required>
			 <br><br>
	       <input type="text" name="phone" placeholder="Phone no" required>
	       <br><br>
			 <input type="text" name="email" placeholder="Email Address" required>
			 <br><br>
			 
			
				 <input type="text" name="date" placeholder="Enter Date" required>
				 <br><br>
				  <input type="text" name="time" placeholder="Enter Time" required>
				  <br><br>
			
           <br><br>
			
            <button type="submit" name="signup-submit">Submit</button>
          </form>
		<?php } ?>
          <!--
          NOTES FOR ME BEFORE DOING PHP!
          <form class="form-signup" action="includes/signup.inc.php" method="post">
            <input type="text" name="uid" placeholder="Username">
            <input type="text" name="mail" placeholder="E-mail">
            <input type="password" name="pwd" placeholder="Password">
            <input type="password" name="pwd-repeat" placeholder="Repeat password">
            <button type="submit" name="signup-submit">Signup</button>
          </form>
          -->
        </section>
      </div>
    </main>

<?php
  // And just like we include the header from a separate file, we do the same with the footer.
  require "includes/footer.php";
?>
