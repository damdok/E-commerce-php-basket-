<?php
	include_once 'dbh.inc.php';

	$pname = $_POST['pname'];
	$quantity = $_POST['quantity'];
	$description = $_POST['description'];
	$productprice = $_POST['price'];
    $type = $_POST['type'];

	$sql = "INSERT INTO products (productid, productprice, quantity, description, type) VALUES ('$pname', '$quantity', '$description', '$price', 'type');";
	mysqli_query($conn, $sql);
	header("Location: ../index.php?addProduct=success");
