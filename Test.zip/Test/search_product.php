<?php
	include_once'header.php';
?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Search Product</h2>
		<div class="tab-main">
		  <input id="tab1" type="radio" name="tabs" checked="">
		  <label class="tabs" for="tab1"><strong></strong></label>		 
		  <div class="content">
			<div id="content1">
				<form action="search_product.php" method="GET">
					<input type="hidden" name="product" value="product"/>
					<div class="grid">
						<div class="row">
						<div class="col">
								Animal<label class="custom-select">
									<select class="custom-select" name="forwhich">
										<option value="">Please Select</option>
										<option value="dog" <?php if($_GET['forwhich'] == 'dog'){?> selected <?php } ?> >Dog</option>
										<option value="cat" <?php if($_GET['forwhich'] == 'cat'){?> selected <?php } ?> >Cat</option>										
									</select>
								</label>
						</div>
                        <div class="col">
								Type<label class="custom-select">
									<select class="custom-select" name="type">
										<option value="">All</option>
										<option value="Food" <?php if($_GET['type'] == 'Food'){?> selected <?php } ?> >Food</option>
										<option value="Toys" <?php if($_GET['type'] == 'Toys'){?> selected <?php } ?> >Toys</option>
										<option value="Treats" <?php if($_GET['type'] == 'Treats'){?> selected <?php } ?> >Treats</option>
										<option value="Caging" <?php if($_GET['type'] == 'Caging'){?> selected <?php } ?> >Caging</option>
									</select>
								</label>
						</div>
						<div class="col">
								price<label class="custom-select">
									<select class="custom-select" name="price">
										<option value="" >All</option>	
										<option value="low" <?php if($_GET['price'] == 'low'){?> selected <?php } ?> >Low(smaller than 10US$)</option>
										<option value="medium" <?php if($_GET['price'] == 'medium'){?> selected <?php } ?> >Medium(10US$ ~ 100US$)</option>
										<option value="high" <?php if($_GET['price'] == 'high'){?> selected <?php } ?> >High(bigger than 100US$)</option>										
									</select>
								</label>
						</div>												
						<div class="col v-align-btm">
							<button class="grid-btn">Search</button>
						</div>
						</div>
					</div>
				</form>
			</div>
		  </div>
		</div>
	</section>



	<div class="posts-wrap">
	<section id="home_latest_posts" class="clearfix">
    <?php 
    	$sql = "select * from pet_products where id >= 0 ";
    	if($_GET['type'] != ''){  $sql .= " and type = '".$_GET['type'] ."' ";  }
    	if($_GET['forwhich'] != ''){  $sql .= " and ForWhich = '".$_GET['forwhich'] ."' ";  }
        if($_GET['price'] != ''){  
        	if($_GET['price'] == "low") { $sql .= " and price < 10.00 ";  }
        	if($_GET['price'] == "medium") { $sql .= " and price >= 10.00 and price <= 100.00"; }
        	if($_GET['price'] == "high") { $sql .= " and price > 100.00 ";  }
        }
    	$query = mysqli_query($conn, $sql);
    	
		while($data = mysqli_fetch_assoc($query)){ ?>
		<article class="single_latest">
			<a href="product-blog-single.php?id=<?php echo $data['id']; ?>" title="Meet Cindy" class="single_latest_img_link">
				<img width="275" height="110" src="images/products/<?php echo $data['image']; ?>" class="attachment-single_latest" alt="Meet Cindy" />
			</a>
			<a href="product-blog-single.php?id=<?php echo $data['id']; ?>">	<h2 style="padding:0px;margin:5px;"><?php echo $data['name']; ?></h2>
            <h4><?php echo $data['type']; ?></h4>
            </a>
            			
			<p>
			</p>
			</article>
		<?php } ?>
        </section> </div>
	
</div>
<?php 
	include_once('includes/footer.php');
?>


