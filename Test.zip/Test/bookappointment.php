<?php
session_start();
error_reporting(0);

if($_SESSION['id'] == ''){
	header('Location: signup.php');
	
	
}
  // To make sure we don't need to create the header section of the website on multiple pages, we instead create the header HTML markup in a separate file which we then attach to the top of every HTML page on our website. In this way if we need to make a small change to our header we just need to do it in one place. This is a VERY cool feature in PHP!
  require "header.php";
  $pet = mysqli_query($conn,"select * from animals where idAnimal = '".$_GET['id']."' ");
  $pdata = mysqli_fetch_assoc($pet);
  
  
?>

    <main>
      <div class="wrapper-main">
        <section class="section-default">
	   <?php if($_GET['id'] != ''){ ?>	<img width="100"  src="images/pets/<?php echo $pdata['img']; ?>" class="attachment-big_latest" alt="Meet Cindy" style="float:left;" />
		<br><br><br>
				
          <h1 style="float:left;">Request to Adopt  <?php echo $pdata['Name']; ?></h1>
		  <br><br>
		  
		  <?php } if (isset($_GET["status"])) {
            if ($_GET["status"] == "1") {
              echo '<p class="signupsuccess" style="text-align:left;">Adoption Request successful!</p>';
            }
          }
		  ?>
        <?php if($_GET['id'] != ''){ ?>
          <form  action="bookappointmentt.php" method="post" enctype="multipart/form-data">
          
		  
		   <input type="hidden" value="<?php echo $_SESSION['id'];?>" name="uid" placeholder="Name" style="width:50%;" required>
		   <br>
            <input type="hidden" value="<?php echo $_GET['id'];?>" name="pid" placeholder="Phone no" required>
             <input type="hidden" value="<?php echo $pdata['dcNumber'];?>" name="dcNumber" placeholder="Phone no" required>
            <br><br>
			 
			 
		     <label for="name">Name</label>   
			 <input type="text" id = "name" name="name" placeholder="Name" style="width:50%;" required>
			 <br><br>
			 <label for="phone">Phone</label> 
	       <input type="text" id="phone" name="phone" placeholder="Phone no" required>
	       <br><br>
	       <label for="email">Email</label>
			 <input type="text" id="email" name="email" placeholder="Email Address" required>
			 <br><br>
			 
			        <label for="date">Requested Day of Adoption:</label>
				 <input type="date" name="date" id="date" value="2019-12-04"
       min="2019-12-04" max="2021-12-31" placeholder="Enter Date" required>
				 <br><br>
				 <label for="appt">Requested Time:</label>
				  <input type="time" id="appt" name="time" value="08:00"
       min="09:00" max="18:00" required>
				  <br><br>
				  <label for="doc">Completed Adoption Form:</label>
			<input type="file" id="doc" name="doc">
           <br><br>
			
            <button type="submit" name="signup-submit">Submit</button>
          </form>
		<?php } ?>
          <!--
          NOTES FOR ME BEFORE DOING PHP!
          <form class="form-signup" action="includes/signup.inc.php" method="post">
            <input type="text" name="uid" placeholder="Username">
            <input type="text" name="mail" placeholder="E-mail">
            <input type="password" name="pwd" placeholder="Password">
            <input type="password" name="pwd-repeat" placeholder="Repeat password">
            <button type="submit" name="signup-submit">Signup</button>
          </form>
          -->
        </section>
      </div>
    </main>

<?php
  // And just like we include the header from a separate file, we do the same with the footer.
  require "includes/footer.php";
?>
