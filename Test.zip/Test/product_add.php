<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<p><a href="product_list.php">Product List Page</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<body>
<body>
<!--Here is a basic example of how to insert data into our database using a simple HTML form-->
<!--Notice that I am using a POST method, and I am sending the data to a script on a separate page-->
<center><form action="product_insert.php"  method="post" enctype="multipart/form-data">
<h1>Add Product To Store:</h1>
	<input type="text" name="pname" placeholder="Name of Product">
	<br><br>
	<input type="text" name="pdescription" placeholder="Description">
	<br><br>
	<input type="text" name="pquantity" placeholder="Quantity">
	<br><br>
    <input type="text" name="pprice" placeholder="Price">
	<br><br>
    <a>Type:</a>&nbsp;&nbsp;<select name="ptype">
				<option value="Food">Food</option>
				<option value="Toys">Toys</option>
				<option value="Treats">Treats</option>
				<option value="Caging">Caging</option>
			</select><br><br>
	<a>For dog or cat only:</a>&nbsp;&nbsp;<select name="pfor">
				<option value="dog">Dog</option>
				<option value="cat">Cat</option>
			</select>
	<br><br>
    <input type="file" name="image">
    <br><br>
	<input type="submit" name="submit" value="upload"></button>
</form></center>

</body>
</html>
<?php include('footer.php'); ?>