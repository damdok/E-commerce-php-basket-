<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "SELECT * from products2 where id='".$id."'"; 
$result = mysqli_query($conn, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Product Approval</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="page-extras.php">Dashboard</a> 
| <a href="includes/logout.inc.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$name =$_REQUEST['name'];
$category_id =$_REQUEST['category_id'];
$price =$_REQUEST['price'];
$description=$_REQUEST['description'];
$image=$_REQUEST['image'];
//INSERT INTO animals2 (Type, Name, Breed, Sex, DOB, Color, Size, img, dcNumber) VALUES ('$type', '$id', '$breed', '$sex', '$DOB', '$color', '$size', '$filename', '$dcNumber');
$update="INSERT INTO products (category_id, name, description, price, image) VALUES ('$category_id', '$name', '$description', '$price', '$image');";
mysqli_query($conn, $update) or die(mysqli_error());
$query = "DELETE from products2 where id='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
$status = "Product Succesfully Added. </br></br>
<a href='productreview.php'>View Remaining Requests</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<center><form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="text" name="productName" placeholder="Enter Name" 
required value="<?php echo $row['name'];?>" /></p>
<p><input type="text" name="productprice" placeholder="Enter Product Price" 
required value="<?php echo $row['price'];?>" /></p>
<p><input type="text" name="quantity" placeholder="Enter Quantity" 
required value="<?php echo $row['category_id'];?>" /></p>
<p><input type="text" name="vNumber" placeholder="Enter vNumber" 
required value="<?php echo $row['description'];?>" /></p>
<p><input type="text" name="img" placeholder="Enter Image" 
required value="<?php echo $row['image'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form></center>
<?php } ?>
</div>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>