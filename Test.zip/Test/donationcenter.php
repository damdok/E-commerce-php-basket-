<?php include('header.php'); ?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Donation Center Homepage</h2>
		<div class="clearfix">
			<div class="entry-content clearfix">
				<p>
                <form action="addanimal.php">
                    <input type="submit" value="Add New Animal for Adoption" />
                </form>
                <br><br>
                <form action="page-extras.php">
                    <input type="submit" value="View/Update Animal Records" />
                </form>
				</p>
			</div>
		</div>


<?php include('includes/footer.php'); ?>