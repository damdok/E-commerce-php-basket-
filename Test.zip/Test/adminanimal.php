<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Animals Available for Adoption</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="adminhome.php">Home</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<h2>Animal's Available for Adoption</h2>
<table width="100%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>#</strong></th>
<th><strong>Name</strong></th>
<th><strong>Age</strong></th>
<th><strong>Breed</strong></th>
<th><strong>Sex</strong></th>
<th><strong>DOB</strong></th>
<th><strong>Color</strong></th>
<th><strong>Size</strong></th>
<th><strong>Animal ID</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>
<?php


//function prompt($prompt_msg){
//        echo("<script type='text/javascript'> var answer = prompt('".$prompt_msg."'); </script>");
//
//        $answer = "<script type='text/javascript'> document.write(parseInt(answer); </script>";
//        return($answer);
//    }

//    //program
//    $prompt_msg = "Please type your name.";
//    $name = prompt($prompt_msg);
//WHERE dcNumber='".$name."' 
$count=1;
$sel_query="Select * from animals ORDER BY idAnimal asc";


$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["Name"]; ?></td>
<td align="center"><?php echo $row["Type"]; ?></td>
<td align="center"><?php echo $row["Breed"]; ?></td>
<td align="center"><?php echo $row["Sex"]; ?></td>
<td align="center"><?php echo $row["DOB"]; ?></td>
<td align="center"><?php echo $row["Color"]; ?></td>
<td align="center"><?php echo $row["Size"]; ?></td>
<td align="center"><?php echo $row["idAnimal"]; ?></td>
<td align="center">
<a href="edit.php?id=<?php echo $row["idAnimal"]; ?>">Edit</a>
</td>
<td align="center">
<a href="admindel.php?id=<?php echo $row["idAnimal"]; ?>">Delete</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>