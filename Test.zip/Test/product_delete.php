<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<?php
include_once 'includes/dbh.inc.php';
$id=$_REQUEST['id'];
$query = "DELETE from pet_products WHERE id='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
echo ("Deleted successfully.");
echo ("<meta http-equiv='Refresh' content='1; URL=product_list.php'>");
?>
</body>
</html>
<?php include('footer.php'); ?>