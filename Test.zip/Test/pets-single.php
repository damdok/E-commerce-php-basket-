<?php include('header.php'); ?>

<div class="posts-wrap">
	<article class="rescue_pet">
		<div class="entry-content clearfix">
			<div id="single_petpost_photos-wrap">
				<div id="single_petpost_photos">
					<a href="images/pets/cindy1.jpg" class="lightbox" rel="gallery">
						<span class="preview"></span>
						<img width="275" height="275" src="images/pets/cindy1-275x275.jpg" class="attachment-pet_single_large" alt="Cinderella" />
					</a>
				</div>
				<div id="single_petpost_thumbnails" class="clearfix">
					<a href="images/pets/cindy2.jpg" class="lightbox" rel="gallery">
						<span class="preview"></span>
						<img width="180" height="180" src="images/pets/cindy2-180x180.jpg" class="attachment-small_pet" alt="Cinderella" />
					</a>
					<a href="images/pets/cindy3.jpg" class="lightbox" rel="gallery">
						<span class="preview"></span>
						<img width="180" height="180" src="images/pets/cindy3-180x180.jpg" class="attachment-small_pet" alt="Cinderella" />
					</a>
					<a href="images/pets/cindy4.jpg" class="lightbox" rel="gallery">
						<span class="preview"></span>
						<img width="180" height="180" src="images/pets/cindy4-180x180.jpg" class="attachment-small_pet" alt="Cinderella" />
					</a>
				</div>
			</div>
			<h2 class="entry-title pet-name-title">Cinderella</h2>
			<div class="breed">
				<a href="pets-animal.php">American Shorthair</a> - <a href="pets-animal.php">Calico</a> - Adult - Female
			</div>
			<div class="pet_info clearfix">
				<span>Adoptable</span>
				<span>Large</span>
				<span>Spayed/Neutered</span>
				<span>Up-to-date with routine shots</span>
				<span>House trained</span>
			</div>
			<p>
			</p>
			<p>
			</p>
		</div>
	</article>
</div>

<?php include('includes/sidebar.php'); ?>

<?php include('includes/footer.php'); ?>