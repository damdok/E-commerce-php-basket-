<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "DELETE from products2 WHERE id='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
header("Location:productreview.php"); 
?>
</body>
</html>
<?php include('footer.php'); ?>