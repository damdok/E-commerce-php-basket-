<?php
	include_once 'dbh.inc.php';
	session_start();
    
    $id=$_SESSION["ak"];
    $email=$_SESSION['email'];
	$idAnimal = $_POST['idAnimal'];
	$Type = $_POST['Type'];
	$Breed = $_POST['Breed'];
    $Sex = $_POST['Sex'];
    $DOB = $_POST['DOB'];
    $Color = $_POST['Color'];
    $Size = $_POST['Size'];
    $description = $_POST['Description'];
    
    
    //declaring variables
    $filename = $_FILES['image']['name'];
    $filetmpname = $_FILES['image']['tmp_name'];
    //folder where images will be uploaded
    $folder = '../images/pets/';
    //function for saving the uploaded images in a specific folder
    copy($_FILES['image']['tmp_name'], $folder.$filename);
    

	$sql = "INSERT INTO animals2 (Type, Name, Breed, Sex, DOB, Color, Size, Description, img, dcNumber) VALUES ('$Type', '$idAnimal', '$Breed', '$Sex', '$DOB', '$Color', '$Size', '$description', '$filename', '$id');";
	mysqli_query($conn, $sql);
	if($Type == 'Dog')
    {
        $Type = '1';
    }
    else if ($Type == 'Cat')
    {
        $Type = '2';
    }
    $query = "SELECT * from animals where Name='$idAnimal'"; 
    $result = mysqli_query($conn, $query) or die ( mysqli_error());
    $row = mysqli_fetch_assoc($result);
    $wow = $row['idAnimal'];
    
	$sql2 = "INSERT INTO booking_calendars (calendar_id, category_id, calendar_title, calendar_email, calendar_order, calendar_active) VALUES ('$wow', '$Type', '$idAnimal', '$email', '0', '1');";
	mysqli_query($conn, $sql2);
	header("Location: ../index.php?addProduct=success");
