<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<p><a href="adminhome.php">Dashboard</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "DELETE from animals where idAnimal='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
header("Location: adminanimal.php"); 
?>

</body>
</html>
<?php include('footer.php'); ?>