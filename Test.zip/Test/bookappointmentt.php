<?php
if (isset($_POST)) {

  include_once 'includes/dbh.inc.php';
  
  $uid = $_POST['uid'];
  $pid = $_POST['pid'];
  $dcNumber = $_POST['dcNumber'];
  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];
  $date = $_POST['date'];
   $time = $_POST['time'];
   
    //declaring variables
    $filename = $_FILES['doc']['name'];
    $filetmpname = $_FILES['doc']['tmp_name'];
    //folder where images will be uploaded
    $folder = 'images/adoptionforms/';
    //function for saving the uploaded images in a specific folder
    copy($_FILES['doc']['tmp_name'], $folder.$filename);
    

   
  $query = mysqli_query($conn , " INSERT INTO `appointment` (`id`, `uid`, `pid`, `dcNumber`, `name`, `phone`, `email`, `date`, `time`, `doc`) VALUES (NULL, '".$uid."', '".$pid."', '".$dcNumber."', '".$name."', '".$phone."', '".$email."', '".$date."', '".$time."', '$filename'); ");
 
  $msg = "Hi,

Your Request has been successfully submitted. We will reply you asap.

Regards
Pet Finder
";


// send email
mail($email,"Pet finder appoitment request",$msg);

   header("Location: bookappointment.php?status=1");
          exit();
}
