<?php 
session_start();
require "includes/dbh.inc.php";
$currentFile = $_SERVER["PHP_SELF"];
$parts = Explode('/', $currentFile);
($page_file_name = ($parts[count($parts) - 1])); 

  
 ?>
<!DOCTYPE html>
<html lang="en-US">
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		
		<title>Pet Detector</title>
		
		<meta name="Keywords" content=" " />
		<meta name="Description" content=" " />
		
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
		
		<!-- CSS -->
		<link rel="stylesheet" href="css/style.css" type="text/css" media="screen" />
		<link rel="stylesheet" href="includes/js/flexslider.css?ver=3.9.1" type="text/css" media="all" />
		<link rel="stylesheet" href="includes/fancybox/jquery.fancybox.css" type="text/css" media="screen" />
		
		<!-- The next line calls the font for the headings from Google. You can customize this at Google.com/fonts */ -->
		<link href='http://fonts.googleapis.com/css?family=Merriweather:300' rel='stylesheet' type='text/css'>
		
		<!-- The Favicon -->
		<link rel="shortcut icon" href="images/favicon.png" />
	</head>
	<body class="content_left scheme_red">
		<section id="main_wrap">
			<header class="wrapper" id="header">
				<div class="container">
					<div id="main_menu" class="clearfix">
						<div class="clearfix">
							<a href="index.php" title="PetDetector" class="the_logo_link">
								<img src="images/rescuelogo.png" alt="PetDetector" id="logo" height="220" width="250.5" />
							</a>
							<nav id="menu_wrap">
								<div class="menu-main-menu-container">
									<ul id="menu-main-menu" class="menu">
										<li><a href="index.php" <?php if ($page_file_name == "index.php") echo 'class="current_page"'; ?>>Home</a></li>
										<li><a href="#" <?php if (($page_file_name == "pets-all.php") || ($page_file_name == "pets-animal.php") || ($page_file_name == "pets-animal.php")) echo 'class="current_page"'; ?>>Adoption</a>
											<ul class="sub-menu">
												<li><a href="pets-animal.php" <?php if ($page_file_name == "pets-animal.php") echo 'class="current_page"'; ?>>All Pets</a></li>
												<li><a href="pets-animal.php" <?php if ($page_file_name == "pets-animal.php") echo 'class="current_page"'; ?>>Cat Adoption</a></li>
												<li><a href="pets-animal.php" <?php if ($page_file_name == "pets-animal.php") echo 'class="current_page"'; ?>>Dog Adoption</a></li>
												<li><a href="pets-animal.php" <?php if ($page_file_name == "pets-animal.php") echo 'class="current_page"'; ?>>Other Animals</a></li>
											</ul>
										</li>
										
										
										<li><a href="#" <?php if (($page_file_name == "page.php") || ($page_file_name == "page-full.php") || ($page_file_name == "page-contact.php") || ($page_file_name == "page-extras.php")) echo 'class="current_page"'; ?>>Pet Care</a>
											<ul class="sub-menu">
												<li><a href="page.php" <?php if ($page_file_name == "page.php") echo 'class="current_page"'; ?>>Ask A Vet</a></li>
												<li><a href="page-full.php" <?php if ($page_file_name == "page-full.php") echo 'class="current_page"'; ?>>Animal Breeds</a></li>
												<li><a href="page-contact.php" <?php if ($page_file_name == "page-contact.php") echo 'class="current_page"'; ?>>Contact Us</a></li>
												<li><a href="page-extras.php" <?php if ($page_file_name == "page-extras.php") echo 'class="current_page"'; ?>>Pet training</a></li>
                                                <li><a href="product_list.php" <?php if ($page_file_name == "product_list.php") echo 'class="current_page"'; ?>>Product Management</a></li>
											</ul>
										</li>
										<li><a href="page-contact.php" <?php if ($page_file_name == "index.php") echo 'class="current_page"'; ?>>Donate</a></li>
										<li><a href="../phpcartoopmvc/phpcartoopmvc-projectfiles/index.php" <?php if ($page_file_name == "index.php") echo 'class="current_page"'; ?>>Services</a></li>
										<li><a href="#" <?php if (($page_file_name == "search.php") || ($page_file_name == "search_product.php")) echo 'class="current_page"'; ?>>Search</a>
										    <ul class="sub-menu">
										        <li><a href="search.php" <?php if ($page_file_name == "search.php") echo 'class="current_page"'; ?>>Search Animal</a></li>
										        <li><a href="search_product.php" <?php if ($page_file_name == "search_product.php") echo 'class="current_page"'; ?>>Search Product</a></li>
										    </ul>
										</li>
											
                                        	<li>        
                                                <?php
                                                if (!isset($_SESSION['id'])) {
                                                echo ' <div class="header-login"><form action="includes/login.inc.php" method="post">
                                                    <input type="text" name="mailuid" placeholder="E-mail/Username">
                                                    <input type="password" name="pwd" placeholder="Password">
                                                    <button type="submit" name="login-submit">Login</button>
                                                </form>
                                                <a href="signup.php" class="header-signup">Signup</a> </div>';
                                                }
                                                else if (isset($_SESSION['id']) && $_SESSION['type'] == user) {
                                                echo '<form action="includes/logout.inc.php" method="post">
                                                    <button type="submit" name="login-submit">Logout</button>
                                                    <a href="user.php" class="header-signup">User Home</a>
                                                 
                                                </form>';
                                                }
                                                else if (isset($_SESSION['id']) && $_SESSION['type'] == vendor) {
                                                echo '<form action="includes/logout.inc.php" method="post">
                                                    <button type="submit" name="login-submit">Logout</button>
                                                    <a href="vendor.php" class="header-signup">Vendor Home</a>
                                                </form>';
                                                }
                                                else if (isset($_SESSION['id']) && $_SESSION['type'] == donationCenter) {
                                                echo '<form action="includes/logout.inc.php" method="post">
                                                    <button type="submit" name="login-submit">Logout</button>
                                                    <a href="donationcenter.php" class="header-signup">D.C. Home</a>
                                                </form>';
                                                }
                                                else if (isset($_SESSION['id']) && $_SESSION['type'] == 'admin') {
                                                echo '<form action="includes/logout.inc.php" method="post">
                                                    <button type="submit" name="login-submit">Logout</button>
                                                    <a href="adminhome.php" class="header-signup">Admin Home</a>
                                                </form>';
                                                }
                                                ?>
                                             </li>
										
									</ul>		
									
								</div>
								
							</nav>
							
						</div>
						
						
					</div>
					
					
				</div>
				
					
			</header>
			<section class="wrapper" id="main_content"><?php // #main_content ends in footer.php ?>
			
			<?php if ($page_file_name == "index.php") { ?>
				<div id="slider_wrap">
					<ul class="slides">
						<li class="slide_image_wrap">
							<img width="2880" height="1000" src="images/slide1.jpg" alt="This is a slide" />
						</li>
						<li class="slide_image_wrap">
							<img width="2880" height="1000" src="images/slide3.jpg" alt="This is a slide" />
						</li>
					</ul>
				</div>
			<?php } ?>
			<!-- took out the clear fix  looked like this before <div class="container clearfix">-->
			<div class="container clearfix">