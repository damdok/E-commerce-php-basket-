<?php include('header.php');
//session_start();
//session_destroy();
?>
<?php 
	
$query = mysqli_query($conn, "select * from pet_products where id = '".$_GET['id']."' ");
$data = mysqli_fetch_assoc($query); 		
$quantity = $data['quantity'];
$product_id = $_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){	
//
		if(isset($_SESSION["shopping_cart"]))
		{
			//
			$item_array_id = array_column($_SESSION["shopping_cart"],"item_id");
			//
			if(!in_array($_GET["id"], $item_array_id))
			{
				//
				$count = count($_SESSION["shopping_cart"]);
				//
				$item_array = array(
				'item_id' => $_GET["id"],
				'item_name' => $data['name'],
				'item_price' => $data['price'],
				'item_quantity' => 1
				);
				//
				$_SESSION["shopping_cart"][$_GET["id"]] = $item_array;
			}else{
				//
				$_SESSION["shopping_cart"][$_GET["id"]]['item_quantity']++;
			}
			$quantity = $data['quantity'] - $_SESSION["shopping_cart"][$_GET["id"]]['item_quantity'];
		}
		else{
			$item_array = array(
			'item_id' => $_GET["id"],
			'item_name' => $data['name'],
			'item_price' => $data['price'],	
			'item_quantity' => 1);
			//
			$_SESSION["shopping_cart"][$_GET["id"]] = $item_array;
			$quantity = $data['quantity'] - 1;
			}
			
}
?>
<div class="posts-wrap clearfix">
	<article class="post">
		<div class="post_content">
			<div class="clearfix">
				<h2 class="entry-title"><?php echo $data['name']; ?></h2>
				<img width="600" height="240" src="images/products/<?php echo $data['image']; ?>" class="attachment-big_latest" alt="Meet Cindy" />
				<p>
					<ul class="commentlist">
						<li class="comment bypostauthor odd">
							<strong> Name :  </strong> <?php echo $data['name']; ?><br>
						</li>
			            	<li class="comment bypostauthor odd">
							<strong> Type :  </strong> <?php echo $data['type']; ?><br>
						</li>
			            	<li class="comment bypostauthor odd">
							<strong> Price :  </strong> <?php echo $data['price']; ?><br>
						</li>
			            <li class="comment bypostauthor odd">
							<strong> Quantity :  </strong> <?php echo $quantity; ?><br>
						</li>            	

			            <li class="comment bypostauthor even">
							<strong> Description :  </strong> <?php echo $data['description']; ?>   <br>
						</li>
						
						<li class="comment bypostauthor even">
						     <?php
								if($quantity > 0){ 																									
							 ?>
							 <form action="product-blog-single.php?id=<?php echo $data['id'];?>" name="add_cart" method="post">
								 <a><input type="submit" value="Add Cart"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								 <a href="search_product.php">Return</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								 <a href="product_busket.php">Show Busket</a>
							 </form>
						 	<?php }else{ ?>
			 				 <a href="search_product.php"> Return</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			 				 <a href="product_busket.php">Show Busket</a>
			 				 <?php } ?> 
						</li>
		            </ul>
				</p>
			</div>
		</div>
	</article>
</div>
<?php include('includes/footer.php'); ?>