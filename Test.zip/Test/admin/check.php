<?php if($_SESSION['uidad'] == ''){	header("Location: logout.php"); }
error_reporting(0);
	session_start();
	
require_once('../includes/dbh.inc.php');
$user = $_POST['uemail'];
$pass = $_POST['upw'];

$qry="SELECT * FROM hash_admin WHERE email='$user' AND pass='$pass'";
 
 

	$result=mysqli_query($conn,$qry);
	
	if(mysqli_num_rows($result) == 1) 
	{
		$sess = mysqli_fetch_assoc($result);
		session_regenerate_id();
	 $_SESSION['adminuser'] = $sess['name']; 
	 $_SESSION['adminid'] = $sess['id'];
	 $_SESSION['adminrole'] = $sess['role'];
	 $_SESSION['adminemail'] = $sess['email'];
	  $_SESSION['uidad'] = 'allow';
			 
			header('Location: index.php');
	
	
} else {
	
	header('Location: login.php?msg=error');
	
}

?>