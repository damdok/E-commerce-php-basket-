 <?php error_reporting(0);
session_start();
require_once('../includes/dbh.inc.php');
 if($_SESSION['uidad'] == ''){	header("Location: logout.php"); }
include "auth.php"; 
error_reporting(1);

 $ListType = $_POST["ListType"];

  $strPage = $_POST['myPage'];

   $name =  $_POST['name'];
   $username =  $_POST['username'];
      $email = $_POST['email'];

      $phone = $_POST['phone'];

	    $where1 = $_POST['pid'];
$value1 =  $_POST['value1'];
 
 
     $where2 = $_POST['where2'];
 $value2 =  $_POST['value2'];


//echo $_POST['ctype'];

  if(isset($_POST['ListType'])) {

		

                    if($_POST['ListType'] == '') {

					       $order_data = 'name';

						    $order_by = 'name ASC';

							

					} else {

					     $order_data = $_POST['ListType'];

					    

              			    $order_by = ''.$order_data.'  ';

					}

					}

					
                    $role = $_SESSION['adminrole'];
                    if($_SESSION['adminrole'] == '0'){
                        $role = '';
                    }
					$strSQL = "select * from appointment  where dcNumber = '$role' ";

					 if($_POST['name'] != '') {

						 $strSQL .=" and  h_user_name like '%".$name."%'";

							 }

							  if($username != '') {

						 $strSQL .=" and  h_user_username like '%".$username."%'";

							 }

							 if($email != '') {

						 $strSQL .=" and  h_user_email like '%".$email."%'";

							 }
							  if($phone != '') {

						 $strSQL .=" and  h_user_type = '".$phone."'";

							 }
							  if($where1 != '') {

						 $strSQL .=" and  WHERE ".$where1." !=  '".$value1."'";

							 }
						
  if($where2 != '') {

						 $strSQL .=" and  ".$where2." !=  ".$value2." ";

							 }
						

						

 $query1 = mysqli_query($conn,$strSQL);

 $Num_Rows = mysqli_num_rows($query1);

$Per_Page = 20;   // Per Page



$Page = $strPage;

if(!$strPage)

{

	$Page=1;

}



$Prev_Page = $Page-1;

$Next_Page = $Page+1;



$Page_Start = (($Per_Page*$Page)-$Per_Page);

if($Num_Rows<=$Per_Page)

{

	$Num_Pages =1;

}

else if(($Num_Rows % $Per_Page)==0)

{

	$Num_Pages =($Num_Rows/$Per_Page) ;

}

else

{

	$Num_Pages =($Num_Rows/$Per_Page)+1;

	$Num_Pages = (int)$Num_Pages;

}





$strSQL .=" order by $order_by LIMIT $Page_Start , $Per_Page";

					

				$product = mysqli_query($conn,$strSQL);	

				

				// echo $strSQL;

				

				?>

					

					

				





							   <table class="table left sortable table-striped" style="color:#000;">

                          <thead class="title">

                            <tr>

                                <th data-sort="string">


                                </th>

                                <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Name</a></th> 
								<th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Email</a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Phone</a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Pet </a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Date</a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Time</a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> View Form</a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Status</a></th> 
 <th data-sort="string">
                                   <a  href="javascript:void(0)" 
 style="color:#000;"> Action</a></th> 
 
 

                            </tr>

                          </thead><tbody class="content">

                           <?php 

	     $ressult_strSQL = mysqli_query($conn,$strSQL);

	    if(mysqli_num_rows($ressult_strSQL) > 0) { 

		      while ($row = mysqli_fetch_assoc($ressult_strSQL)) 

				{?>

                            <tr> <td></td>

                              <td><?php echo $row['name']; ?></td>
							     <td><?php echo $row['email']; ?></td>
								    <td><?php echo $row['phone']; ?></td>
								       <td><?php 
									    $pet = mysqli_query($conn,"select * from animals where idAnimal = '".$row['pid']."' ");
  $pdata = mysqli_fetch_assoc($pet);
									   
									   
									   
									   
									   
									   
									   echo $pdata['Name']; ?></td>
							     <td><?php echo $row['date']; ?></td>
								    <td><?php echo $row['time']; ?></td>
                                    <td > 
                                	<?php ?>
                                <a href="../images/adoptionforms/<?php echo $row['doc']; ?>" class="btn-primary colored-button button btn-xs" style="float:left;">Submitted Form</a>
                                	<?php ?>
                                		
                                	
                                	</td>
										   <td><?php if ($row['status']=='1'){
											   echo '<a  class="btn-primary colored-button button btn-xs"> Approved </a>';}
											   else{ echo '<a  class="btn-danger colored-button button btn-xs"> Pending</a>';}?>
											</td>
											 
	<td > 
	<?php if ($row['status']=='0'){ ?>
<a href="approved.php?id=<?php echo $row['id']; ?>" class="btn-danger  btn" style="float:right;">Approved this Request</a>
	<?php } ?>
		
	
	</td>

                            </tr><?php }}?>

                           

                          </tbody></table>

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

                          </div>

                          <div style="clear:both"></div>

                          <?php

echo '<div style="text-align: right;">';

if($Prev_Page) 

{

	echo " <a href=\"JavaScript:doCallAjax('$order_data','$Prev_Page','$username','$name','$email','$phone','$where1','$value1','$where2','$value2')\"></a> ";

}



for($i=1; $i<=$Num_Pages; $i++){

	if($i != $Page)

	{

		echo " <a href=\"JavaScript:doCallAjax('$order_data','$i','$username','$name','$email','$phone','$where1','$value1','$where2','$value2')\"  style='color:#900;'><button class='btn btn-red btn-mini'>$i</button></a> ";

	}

	else

	{

		echo "<button class='btn btn btn-mini'>$i</button>";

	}

}

if($Page!=$Num_Pages)

{

	echo " <a href=\"JavaScript:doCallAjax('$order_data','$Next_Page','$username','$name','$email','$phone','$where1','$value1','$where2','$value2')\"></a> ";

}

 echo '</div>';

?>