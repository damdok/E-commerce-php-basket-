<?php session_start();

error_reporting(0);

$page = "login";




?> <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
      <link rel="shortcut icon" href="../assets/images/favicon.ico">

    <title>Pet Finder</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet" />
 <script type='text/javascript' src='http://code.jquery.com/jquery-1.8.3.js'></script>
         <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.js"></script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

  <body class="full-width"  <?php if($_SESSION['uidad'] == ''){?> onload="latest2(); <?php } ?>"> <?php //include('top2.php'); ?>

    <div class="container">
 <br style="clear:both;">

      <br style="clear:both;">

      <form class="form-signin" action="check.php" method="post" name="form4" id="form4">
        <h2 class="form-signin-heading">Login to Admin Panel</h2>
      <font style="color:#F00; padding-left:5px;"><?php
					if (isset($_GET['msg'])){
			if($_GET['msg'] == "error" ){ echo "Wrong Email id or Password";
				
				
				
			} 
			if($_GET['msg'] == "done" ){ echo "Password has been sent to your email address";
				
				
				
			} 
			
			
			
			
			
			
			} 
			
			
			?></font>
        <div class="login-wrap"> 
          
            <input type="text" class="form-control" placeholder="Username Or Email Address " autofocus  type="text" name="uemail" id="uemail" > 
             <input type="password" class="form-control" placeholder="Password" name="upw" id="upw" >
           <br>
             
            <button class="btn btn-lg btn-login btn-block" type="submit" name="sign-up" id="sign-up">Login</button>
         
        
        </div>


      </form>

    </div>



    <!-- js placed at the end of the document so the pages load faster -->
<div id="light5" class="white_content" style="display: none; ">			<p style="color:#000;text-align:justify; padding:5px; font-size:16px;">			 	<form class="modal-background form-material tab-pane transition scale fade in active" id="signin-form2" autocomplete="off">                        <div class="modal-heading">                            <h2 class="icon-color">Get Access</h2>                        </div>                       <br><Br>                        <div class="form-group mt20">						 <label class="float-label" for="txtpassword">Enter Password</label>                            <input type="password" class="form-control" required="" data-ng-model="lPsw" id="txtpassword" name="password">                            <span class="form-bar"></span>                                                   </div>												<Br>                        <div class="clearfix"><div id="result322" style="background:pink; color:red;"></div>                            <a id="sign-in2" class="col-md-12 col-xs-12 login-modal-btn colored-button button btn btn-primary common-btn float-button-light mob-login-modal-btn mb20">                                <h3 class="text-center">Get Access</h3>                            </a>                        </div>                        <!-- Switching forms (Fake nav tab) -->                                           </form>						<br>		<br></p></div><div id="fade2" class="black_overlay" style="display: none; "></div><style>.white_content {			display: none;			position: fixed; top: 50px; left:400px ;						width: 430px;						padding: 4px;								z-index:1002;			overflow: auto;												... /* -- CSS3 - define rounded corners -- */	-webkit-border-radius: 10px;-moz-border-radius: 10px; border-radius: 10px; /* -- CSS3 - create a background gradient -- */background: -webkit-gradient(linear, 0% 0%, 0% 40%, from(#EEE), to(#FFF)); background: -moz-linear-gradient(0% 40% 90deg,#FFF, #EEE);  /* -- CSS3 - add a drop shadow -- */-webkit-box-shadow:0px 0 20px #ccc;-moz-box-shadow:0px 0 20px #ccc; box-shadow:0px 0 20px #ccc;											}        .black_overlay{			display: none;			position: absolute;			top: 0%;			left: 0%;			width: 100%;			height: 330%;			background-color: black;			z-index:1001;			-moz-opacity: 0.6;			opacity:.60;			filter: alpha(opacity=80);		}@media (max-width: 768px) {		.white_content {			display: none;			position: fixed; top: 30px; left:5%;			width: 90%;			padding: 4px;			background-color: white;			z-index:1002;			overflow: auto;		}				}</style>			<script>function latest()    {   newWindow =document.getElementById('light5').style.display='block';  document.getElementById('fade2').style.display='block';           }function login()    {     newWindow =document.getElementById('light2').style.display='block';  document.getElementById('fade2').style.display='block';           }	function forget()    {document.getElementById('light2').style.display='none';      newWindow =document.getElementById('light4').style.display='block';  document.getElementById('fade2').style.display='block';           }	function signup()    {      newWindow =document.getElementById('light3').style.display='block';  document.getElementById('fade2').style.display='block';           }	function change1()    { document.getElementById('light4').style.display='none';   newWindow =document.getElementById('light2').style.display='block';  newWindow =document.getElementById('light3').style.display='none';      }		function change2()    {  document.getElementById('light2').style.display='none';     document.getElementById('light3').style.display='block';     }		function closebox()    {document.getElementById('light5').style.display='none';  	document.getElementById('light2').style.display='none';  	document.getElementById('light4').style.display='none';     document.getElementById('light3').style.display='none';document.getElementById('fade2').style.display='none';     }		</script>
<script >							$("#sign-in").click(function() { $('#result32').html('<img src="images/loading.gif" class="loader" />').fadeIn();var input_data = $('#signin-form').serialize();$.ajax({type: "POST",url:  "logex.php",data: input_data,success: function(msg){$('.loader').remove();$('<div>').html(msg).appendTo('div#result32').hide().fadeIn('slow'); $(this).ajaxSubmit(options); }});return false;});				$("#sign-in2").click(function() { $('#result322').html('<img src="images/loading.gif" class="loader" />').fadeIn();var input_data = $('#signin-form2').serialize();$.ajax({type: "POST",url:  "access.php",data: input_data,success: function(msg){$('.loader').remove();$('<div>').html(msg).appendTo('div#result322').hide().fadeIn('slow'); $(this).ajaxSubmit(options); }});return false;});						$("#forget-in").click(function() { $('#result322').html('<img src="images/loading.gif" class="loader" />').fadeIn();var input_data = $('#forget-form').serialize();$.ajax({type: "POST",url:  "recover.php",data: input_data,success: function(msg){$('.loader').remove();$('<div>').html(msg).appendTo('div#result322').hide().fadeIn('slow'); $(this).ajaxSubmit(options); }});return false;});					</script><script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" ></script> <script src="//code.jquery.com/ui/1.10.4/jquery-ui.js" ></script>
 
  </body>
</html>
