<?php 
error_reporting(0);
	session_start();
	
require_once('../includes/dbh.inc.php');


$id = $_GET['id'];

$query = mysqli_query($conn,"select * from  appointment  where id = '".$id."'   ");
$data = mysqli_fetch_assoc($query);


$sql = mysqli_query($conn,"update appointment set status = '1' where id = '".$id."'   ");


 $msg = "Hi,

Your Request has been successfully Approved. We will reply you asap.

Regards
Pet Finder
";
//echo $data['email'];

// send email
mail($data['email'],"Pet finder appoitment request",$msg);

//echo $data['email'];

header("location: index.php ");


?>