<?php 
require_once('../include/config.php');if($_SESSION['uidad'] == ''){	header("Location: logout.php"); }
require_once('../include/function.php');
if($_POST){


	  $opass=$_POST['opass'];
	  $npass=$_POST['npass'];
	   $npass2 = $_POST['npass2'];
	  
	
	if($npass != $npass2)
		{
		   $error .="*New Password and Confrm New Password should be same<br>";
		 } 
	
		  if(strlen($npass)<=4)
		{
		   $error .="*Passwod shuld be atleast 5 digit<br>";
		 }

		 

$rs_duplicate2 = mysql_query("select count(*) as total from hash_admin  where pass ='$opass' and role ='1'  ") or die(mysql_error());
list($total2) = mysql_fetch_row($rs_duplicate2);
if ($total2 < 1)
{
 $error .=$reqicon."Incorrect Old Password . <br>";
}








	if($error!=""){
	//header('Location: addfacilities.php?error='.$error.'".$name."');
	echo $error;
	
}else{


  
    $update = mysql_query("update hash_admin set pass = '$npass' where id = '1'")	;
   
	echo "<script type='text/javascript'>document.getElementById('signup-form').innerHTML = 'You have successfully Updated your profile.'</script>";
	
} }
	
?>
