<?php 
session_start();
require_once('../includes/dbh.inc.php');
$page = 'home';

 include 'top.php'; ?>
  <script type="text/javascript"> function doCallAjax(ListType,Page,name,loc,type,fcode,add1,zonal,ctype,ctype2) {
	     HttPRequest = false;

		   if (window.XMLHttpRequest) { // Mozilla, Safari,...

			 HttPRequest = new XMLHttpRequest();

			 if (HttPRequest.overrideMimeType) {

				HttPRequest.overrideMimeType('text/html');

			 }

		  } else if (window.ActiveXObject) { // IE

			 try {

				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");

			 } catch (e) {

				try {

				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");

				} catch (e) {}

			 }

		  } 

		  

		  if (!HttPRequest) {

			 alert('Cannot create XMLHTTP instance');

			 return false;

		  }

	      document.getElementById("mySpan").innerHTML = "";

			var url = 'listing_user.php';

			var pmeters = "ListType=" + ListType +

						"&myPage=" + Page +

						"&username=" + name +

						"&name=" + loc +

						"&email=" + type +

						"&phone=" + fcode +

						"&where1=" + add1 +

						"&value1=" + zonal +

						"&where2=" + ctype +

						"&value2=" + ctype2;

             

			HttPRequest.open('POST',url,true);



			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

			HttPRequest.setRequestHeader("Content-length", pmeters.length);

			HttPRequest.setRequestHeader("Connection", "close");

			HttPRequest.send(pmeters);

			

			

			HttPRequest.onreadystatechange = function()

			{



				 if(HttPRequest.readyState == 3)  // Loading Request

				  {

				   document.getElementById("mySpan").innerHTML = "<div style='clear:both;'></div>  <center><img src='../images/loading.gif' align='middle' style='text-align:center;margin-top:140px;' /></center>";

				  }



				 if(HttPRequest.readyState == 4) // Return Request

				  {

				   document.getElementById("mySpan").innerHTML = HttPRequest.responseText;

				  }

				

			}





	   }

       
function filter(){
	
	username = document.getElementById('username').value;
	pid = document.getElementById('pid').value;
		name = document.getElementById('name').value;
			email = document.getElementById('email').value;
				phone = document.getElementById('phone').value;			
	doCallAjax('id','1',username,name,email,phone,'','','','');
}

       </script>
      <!--header end-->
      <!--sidebar start-->
   <?php echo include 'aside.php'; ?>
      <!--sidebar end-->
      <!--main content start-->
	  
      <section id="main-content">
          <section class="wrapper">
              <!--state overview start-->
            
              <div class="row state-overview" style="display:none;">
              <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                  <div class="col-lg-4 col-sm-6">
                      <section class="panel">
                          <div class="symbol my-s lighttodarkblue">
                             <h2 >ICO START ON </h2>
                          </div>
                              <h3 class="sec2 text-left ">
                                <?php //echo date("M, d, Y", strtotime(getsetting('ldate','h_setting_value'))); ?>
                              </h3>
                              <hr class="border-bottom"></hr>
                              <p class="text-left padding-right ">warning Start in 00h 00 Nov 3, 2017 UTC</p>
                          
                      </section>
                 </div>
                  <div class="col-lg-4 col-sm-6">
                     <section class="panel">
                          <div class="symbol my-s lighttodarkyellow " >
                             <h2 >Available Coin</h2>

                          </div>
                          
                              <h2 style="text-align:center;" class="sec2">
                                <?php //echo availcoin(); ?>
                              </h2>
                              <hr class="border-bottom"></hr>
                              <p class="text-left padding-right "> <i class="icon-foursquare biticon"></i> Total sale 8,000,000 RCA</p>
                          
                      </section>
                  </div>
                  <div class="col-lg-4 col-sm-6">
                      <section class="panel">
                          <div class="symbol my-s lighttodarkorange">
                             <h2 >Sold Coin</h2>

                          </div>
                          
                              <h3 class="sec2 text-left ">
                                 <?php //echo soldcoin3(); ?>
                              </h3>
                              <hr class="border-bottom"></hr>
                              <p class="text-left padding-right "> <i class="icon-thumbs-up biticon"></i> Total sold </p>
                          
                      </section>
                  </div>
                  
                  </div>
              </div>
              <!--state overview end-->

















      <div class="col-lg-12" style="display:none;">
				  
				     
   
                      <!--work progress start-->
                      <section class="panel">

</section></div>

   
           
                  <div class="col-lg-12">
				  
				     
   
                      <!--work progress start-->
                      <section class="panel">
                          <div class="panel-body progress-panel">
                          
                         
                              
                               <div class="text-center mbot30">
                      
                      <h3 class=" timeline-title eth-title">Adoption Request Control Panel</h3>
                      </div>
                              
                          </div>
						  
	   <div class="col-sm-2" style="display:none;">
	   <input type="text" value="" name="username" id="username" class="form-control" placeholder="Enter Username">
	   </div>
					  
		<div class="col-sm-2" style="display:none;">
	   <input type="text" value="" name="name" id="name" class="form-control" placeholder="Enter Name">
	   </div>

<div class="col-sm-2" style="display:none;">
	   <input type="text" value="" name="email"  id="email" class="form-control" placeholder="Enter Email">
	   </div>

<div class="col-sm-2"  style="display:none;">
	  <select name="phone" id="phone" class="form-control">
	   <option value=""> Select Gender</option>
	  <option value="1"> Male</option>
	    <option value="2"> FeMale</option>
		</select>
	   </div>	   
						  
<div class="col-sm-2" style="display:none;">
	   <button class="btn-primary colored-button button btn" onclick="filter()"  > Filter</button>
	   </div>						  
						  
						  
						  
						  
						  
						  
						  
						  
						  
						    <div id="mySpan" style="margin-top:10px;" >

    <div style='clear:both;'></div>  <center><img src='images/loading.gif' align='middle' style='text-align:center;margin-top:140px;' /></center>

  </div> 
						  
						  
						  
					<br style="clear:both;">	  
					<br style="clear:both;">	<br style="clear:both;">	<br style="clear:both;">	<br style="clear:both;">	<br style="clear:both;">	
						  
						  
						  
						  
						  
						  
						  
                         
                        
                      </section>
                      <!--work progress end-->
                  </div>
              
              
              
  

          </section>
      </section>
	  <script>window.onload = doCallAjax('id DESC','1','','','','','','','','');
</script>
      <!--main content end-->
      <!--footer start-->
      <?php include 'footer.php'; ?>