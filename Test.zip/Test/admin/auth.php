<?php if($_SESSION['uidad'] == ''){	header("Location: logout.php"); }
	//Start session
ini_set("session.gc_maxlifetime", "50");  
	session_start();
	
	//Check whether the session variable SESS_MEMBER_ID is present or not
	if(!isset($_SESSION['adminid']) || (trim($_SESSION['adminid']) == '')) {
		header("location: login.php");
		exit();
	}
	
$_SESSION['timeout'] = time();
 if ($_SESSION['timeout'] + 3 * 60 < time()) {
     header("location: login.php");
  } 
  function getusername($id){
$sql = mysql_query("select h_user_username from hash_user where h_user_id = '".$id."' ");	  

$data = mysql_fetch_assoc($sql);
	  return $data['h_user_username'];
	  
  }
function totalcount($id,$id2,$id3,$id4,$id5,$id6){
	
$sql = 'select '.$id2.' from '.$id;

if($id3 != '' ){
$sql .= ' where '.$id3.' != "'.$id4.'"';
}
if($id5 != '' ){
$sql .= ' and  '.$id5.' != '.$id6;
}

$sql2 = mysql_query($sql);
$count = mysql_num_rows($sql2);

return $count;



}	
 
?>