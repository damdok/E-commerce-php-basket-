<?php 
$page = 'password';
include '../include/config.php';
$rand = rand(1000,9999);
 include 'top.php'; ?>
      <!--header end-->
      <!--sidebar start-->
   <?php echo include 'aside.php'; ?>
      <!--sidebar end-->
      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
              <!--state overview start-->
              <div class="">
             <div class="">  <div class="col-lg-12">
			
			   <h1 style="color:#000;text-align:center;"  >  <p id="demo"></p></h1>
						

<br>
           <section class="panel">
                          <header class="panel-heading">
                        Change Password
                          </header>
                          <div class="panel-body">
                            <form class="form-horizontal tasi-form" id="signup-form">
                    <input type="hidden" name="id" id="id" value="<?php echo $_SESSION['id']; ?>" >
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Old Password</label>
                                      <div class="col-sm-8">
                                          <input type="text" value="<?php  ?>" name="opass" class="form-control">
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">New Password</label>
                                      <div class="col-sm-8">
                                          <input type="text" value="<?php ?>"  class="form-control" name="npass">
                                                  </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-4 col-sm-4 control-label">Confirm New Password</label>
                                      <div class="col-sm-8">
                                          <input type="text" value="<?php  ?>"  class="form-control round-input" name="npass2">
                                      </div>
                                  </div>
                                 							  			  
								   <div class="form-group">
								  <div id="result3" style="background:pink; color:red;"></div>
                            <a id="sign-up" style="" class="col-md-12 col-xs-12 login-modal-btn colored-button button btn btn-primary common-btn float-button-light mob-login-modal-btn mb20">
                                <h3 class="text-center">Update</h3>
                            </a></div>
								  
								  
								  
								  
								  
								  
                               </form>
					<script >
					$("#sign-up").click(function() { 

$('#result3').html('<img src="images/loading.gif" class="loader" />').fadeIn();
var input_data = $('#signup-form').serialize();

$.ajax({
type: "POST",
url:  "regex.php",
data: input_data,
success: function(msg){
$('.loader').remove();
$('<div>').html(msg).appendTo('div#result3').hide().fadeIn('slow');
 $(this).ajaxSubmit(options); 
}
});
return false;

});
			
					
					</script>
                          </div>
                      </section>
            </div> 











			</div>
            
            
              
                  
              
               
          </section>
      </section>
	   <script >	








 </script>	
      <!--main content end-->
      <!--footer start-->
           <?php include 'footer.php'; ?>