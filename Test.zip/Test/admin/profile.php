<?php 
error_reporting(0);
$rand = rand(1000,9999);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


include "../include/config.php"; 
include "../include/function.php"; 
if($_SESSION['uidad'] == ''){
	header("Location: logout.php"); 
}

if($_POST['status'] != ''){
$user1 = mysql_query("select * from hash_user2 where h_user_id =  '".$_POST['uid']."'");
$user = mysql_fetch_assoc($user1);
		echo "Update hash_user2 set h_status_active = '".$_POST['status']."' where h_user_id =  '".$_POST['uid']."' ";
	
	$user1 = mysql_query("Update hash_user2 set h_status_active = '".$_POST['status']."' where h_user_id =  '".$_POST['uid']."' ");
	$user = mysql_fetch_assoc($user1);
	header('Location: profile.php?id='.$_POST['uid']);
	
}

$user1 = mysql_query("select * from hash_user2 where h_user_id =  '".$_GET['id']."' ");

 $count = mysql_num_rows($user1);

if($count > 0 ) {


$data = mysql_fetch_assoc($user1);
$id = $data['h_user_username'];
 
 
 
 
?>





   




      <!--header start-->

     <?php include('top.php'); ?> 
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script>
      <!--header end-->
	  </form>




      <!--sidebar start-->

     

              <!-- sidebar menu end-->

       

      <!--sidebar end-->

      <!--main content start-->
 <?php echo include 'aside.php'; ?>
  
  
    <section id="main-content">
          <section class="wrapper">
              <!-- page start-->
              <div class="row">
                 <aside class="profile-nav col-lg-3">
                      <section class="panel">
                          <div class="user-heading round">
                              <a href="#">
                                  <img src="<?php echo getpic($data['h_user_id']); ?>" alt="" style="width:140px; height:140px;">
                              </a>
                              <h1><?php echo $data['h_user_name']; ?></h1>
                              <p><?php echo $data['h_user_email']; ?></p>
							  
							  
							  <form name="statusform" action="profile.php" method="POST" id="statusform" >
		<div class="col-md-12">
  <input type="hidden" name="uid" id="uid" class="form-control" value="<?php echo $_GET['id']; ?>">   
  
  
  <select name="status" id="status" class="form-control" >
							    <option value="1" <?php if($data['h_status_active'] == '1'){ echo "selected"; } ?>>Active</option>
							  <option value="0" <?php if($data['h_status_active'] == '0'){ echo "selected"; } ?>>DeActive</option>
							  </select>    </h3><br> </div>
							  
							  
							  
							 
							    <div class="col-md-12" style="text-align:center;">
							    <div id="result3" style="background:pink; color:red;"></div>
							  <center><button type="submit" id="addstatus" class="login-modal-btn colored-button button btn-xs btn-primary common-btn ">Submit</button></center>
							  </div>
							  
							  
							  
							  
							  
							  
</form>



                          </div>
 
                        
                      </section>
                  </aside>
                  <aside class="profile-info col-lg-9">
				   
                                           <section class="panel">
                          <div class="bio-graph-heading">
                           Basic Info
                          </div>
                          <div class="panel-body bio-graph-info">
                             
                              <div class="row">
                                  <div class="bio-row">
                                      <p><strong>Name </strong>: <?php echo $data['h_user_name']; ?></p>
                                  </div>
								   <div class="bio-row">
                                      <p><strong>Username </strong>: <?php echo $data['h_user_username']; ?></p>
                                  </div>
                                
                                  <div class="bio-row">
                                      <p><strong>Email </strong>: <?php echo $data['h_user_email']; ?></p>
                                  </div>
                                
								  <div class="bio-row">
                                      <p><strong>Gender </strong>: <?php if($data['h_user_type'] == '1'){  echo 'Male'; } else{  echo 'Female';  } ?></p>
                                  </div>
								  
								  
								  
								  
								  
								  
                                
								
                              </div>
                          </div>
						  <hr>
						 
                        <h3 style="padding:10px;"> About </h3>
                       
						  
						  <p style="text-align:justify;padding:10px;"><?php echo $data['h_about']; ?><p>
						  
						  <br><br>
						  
                      </section>
					   <section class="panel">
                          <div class="panel-body profile-activity">
                            
							
							<span id="txtHint"></span>
							
							  
							  

                          </div>
						  
                      </section>
					  
					
                  </aside>
              </div>

              <!-- page end-->
          </section>
      </section>

      

	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
  <!--main content end-->
      <!--footer start-->
        <footer class="site-footer">
          <div class="text-center">
              2013 &copy; Jefferson Connects .
              <a href="#" class="go-top">
                  <i class="icon-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->


    <!-- js placed at the end of the document so the pages load faster -->

    <script src="js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="js/jquery.scrollTo.min.js"></script>
    <script src="js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="js/jquery.sparkline.js" type="text/javascript"></script> <script src="js/bootstrap-switch.js"></script>  <!--custom tagsinput-->  <script src="js/jquery.tagsinput.js"></script>
    <script src="assets/jquery-easy-pie-chart/jquery.easy-pie-chart.js"></script>
    <script src="js/owl.carousel.js" ></script>
    <script src="js/jquery.customSelect.min.js" ></script>
    <script src="js/respond.min.js" ></script>

    <script class="include" type="text/javascript" src="js/jquery.dcjqaccordion.2.7.js"></script>

    <!--common script for all pages-->
    <script src="js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="js/sparkline-chart.js"></script>
    <script src="js/easy-pie-chart.js"></script>
    <script src="js/count.js"></script>

  <script>

      //owl carousel

      $(document).ready(function() {
          $("#owl-demo").owlCarousel({
              navigation : true,
              slideSpeed : 300,
              paginationSpeed : 400,
              singleItem : true,
			  autoPlay:true

          });
      });

      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>
 <script>
function showposts(str) {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) { 
        document.getElementById("txtHint").innerHTML = this.responseText;
      }
    };
    xmlhttp.open("GET", "../getposts.php?q=" + str, true);
    xmlhttp.send();
  
} showposts(<?php echo $data['h_user_id']; ?>);

function delposts(str) {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        showposts('');
      }
    };
    xmlhttp.open("GET", "../delposts.php?q=" + str, true);
    xmlhttp.send();
  
}


      //knob
      $(".knob").knob();

  </script>





  </body>

</html>

<?php } else { echo "this is not found";  } ?>