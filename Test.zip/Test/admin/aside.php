   <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
                  <li>
                      <a <?php if($page == 'home'){ ?> class="active" <?php } ?> href="index.php">
                          <i class="icon-dashboard"></i>
                          <span>Adoption Requests</span>
                      </a>
                  </li> 
                 

  
				  
                   <li>
                      <a  <?php if($page == 'points'){ ?> class="active" <?php } ?>   href="logout.php">
                          <i class="icon-envelope"></i>
                          <span>Logout </span>
                         
                      </a>
                  </li>
                 
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>