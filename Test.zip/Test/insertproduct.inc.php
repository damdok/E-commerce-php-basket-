<?php
	include_once 'includes/dbh.inc.php';
    session_start();
    
    //$id=$_SESSION["ak"];
    $type = $_POST['type'];
    $productprice = $_POST['price'];
	$pname = $_POST['pname'];
	$quantity = $_POST['quantity'];
	$description = $_POST['description'];
    
    //declaring variables
    $filename = $_FILES['image']['name'];
    $filetmpname = $_FILES['image']['tmp_name'];
    //folder where images will be uploaded
    $folder = '../phpcartoopmvc/phpcartoopmvc-projectfiles/resources/images/';
    //function for saving the uploaded images in a specific folder
    copy($_FILES['image']['tmp_name'], $folder.$filename);
    

	$sql = "INSERT INTO pet_products (type, quantity, name, description, price, image) VALUES ('$type', $quantity, '$pname', '$description', '$productprice', '$filename')";
	mysqli_query($conn, $sql);
	header("Location: productlisting.php");
?>
