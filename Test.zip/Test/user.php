<?php include('includes/header.php'); ?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">User Homepage</h2>
		<div class="clearfix">
			<div class="entry-content clearfix">
				<p>
				    <form action="lookupadoption.php">
                    <input type="submit" value="Adoption Requests" />
                </form>
				</p>
			</div>
		</div>


<?php include('includes/footer.php'); ?>