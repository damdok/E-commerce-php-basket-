<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<p><a href="page-extras.php">Dashboard</a> 
| <a href="addanimal.php">Insert New Record</a> 
| <a href="includes/logout.inc.php">Logout</a></p>
<?php
include_once 'dbh.inc.php';
$id=$_REQUEST['id'];
$query = "DELETE from animals2 where id='".$id."'"; 
$result = mysqli_query($conn,$query) or die ( mysqli_error());
header("Location: adminreview.php"); 
?>

</body>
</html>
<?php include('footer.php'); ?>