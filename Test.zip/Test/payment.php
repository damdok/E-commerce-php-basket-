<html>
<head>
<title>busket</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container" style="width:700px;">
<h2 align="center">paypal payment</h2>
<br>
<br /><br />
<div style="clear:both"></div>
<?php
$totalvalue = $_GET['total'];
?>
<div align="center">
<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">
<input type="hidden" name="cmd" value="_xclick">
<input type="hidden" name="business" value="meet23696@gmail.com">
	Amount to pay : <input type="text" name="amount" value=<?php echo $totalvalue; ?>>(US$)<br /><br />
    encoding : <input type="text" name="charset" value="UTF-8"><br /><br />
<input type="image" name="submit" border="0" src="images/paypal_image.jpg" alt="">
</form>
</div>

</body>
</html>