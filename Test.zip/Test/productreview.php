<?php include('header.php'); ?>

<?php
include_once 'dbh.inc.php';
?>
<!DOCTYPE html>
<html>
<script>
    function clicked() {
    return confirm('Are you sure you want to delete this Animal?');
}</script>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Products's Awaiting Admin Approval</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="adminhome.php">Home</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<h2>Products's Awaiting Admin Approval</h2>
<table width="100%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>#</strong></th>
<th><strong>Name</strong></th>
<th><strong>Type</strong></th>
<th><strong>Price</strong></th>
<th><strong>ProductID</strong></th>
<th><strong>Description</strong></th>
<th><strong>Image</strong></th>
<th><strong>Aprrove</strong></th>
<th><strong>Reject</strong></th>
</tr>
</thead>
<tbody>
<?php


//function prompt($prompt_msg){
//        echo("<script type='text/javascript'> var answer = prompt('".$prompt_msg."'); </script>");
//
//        $answer = "<script type='text/javascript'> document.write(parseInt(answer); </script>";
//        return($answer);
//    }

//    //program
//    $prompt_msg = "Please type your name.";
//    $name = prompt($prompt_msg);
//WHERE dcNumber='".$name."' 
$count=1;
$sel_query="Select * from products2 ORDER BY id asc";


$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["category_id"]; ?></td>
<td align="center"><?php echo $row["price"]; ?></td>
<td align="center"><?php echo $row["id"]; ?></td>
<td align="center"><?php echo $row["description"]; ?></td>
<td align="center"><?php echo $row["image"]; ?></td>
<td align="center">
<a href="approvalprod.php?id=<?php echo $row["id"]; ?>">Finalize Submission</a>
</td>
<td align="center">
<a href="deleteproduct.php?id=<?php echo $row["id"]; ?>" onclick="return clicked();">Deny Submission</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>