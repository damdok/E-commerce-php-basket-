<?php
 require 'includes/dbh.inc.php';
  
if (isset($_POST)) {

 // require 'includes/dbh.inc.php';
  
  $uid = $_POST['uid'];
  $pid = $_POST['pid'];

  $name = $_POST['name'];
  $phone = $_POST['phone'];
  $address = $_POST['address'];
  $why = $_POST['why'];
   $when = $_POST['when'];

   
  $query = mysqli_query($conn , " INSERT INTO `adopt` (`id`, `uid`, `pid`, `name`, `phone`, `address`, `why`, `whenn`) VALUES (NULL, '".$uid."', '".$pid."', '".$name."', '".$phone."', '".$address."', '".$why."', '".$when."'); ");
 
   header("Location: adoptme.php?status=1");
          exit();
}
