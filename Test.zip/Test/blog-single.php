<?php include('header.php'); 
?>
 <?php 
$query = mysqli_query($conn, "select * from animals where idAnimal = '".$_GET['id']."' ");
$data = mysqli_fetch_assoc($query); ?>
		
		
<div class="posts-wrap clearfix">
	<article class="post">
		<div class="post_content">
			<div class="clearfix">
				<h2 class="entry-title"><?php echo $data['Name']; ?></h2>
				<img width="600" height="240" src="images/pets/<?php echo $data['img']; ?>" class="attachment-big_latest" alt="Meet Cindy" />
				<p>

<ul class="commentlist">
			<li class="comment bypostauthor odd">
				<strong> Name :  </strong> <?php echo $data['Name']; ?>   <br>
			</li>
            	<li class="comment bypostauthor odd">
				<strong> Type :  </strong> <?php echo $data['Type']; ?>   <br>
			</li>
            	<li class="comment bypostauthor odd">
				<strong> Breed :  </strong> <?php echo $data['Breed']; ?>   <br>
			</li>
            <li class="comment bypostauthor odd">
				<strong> Sex :  </strong> <?php echo $data['Sex']; ?>   <br>
			</li>
            	<li class="comment bypostauthor odd">
				<strong> Age :  </strong> <?php echo $data['DOB']; ?>   <br>
			</li>
            	<li class="comment bypostauthor odd">
				<strong> Color :  </strong> <?php echo $data['Color']; ?>   <br>
			</li>
            <li class="comment bypostauthor odd">
				<strong> Size :  </strong> <?php echo $data['Size']; ?>   <br>
			</li>

            <li class="comment bypostauthor even">
				<strong> Description :  </strong> <?php echo $data['Description']; ?>   <br>
			</li>
			
			   <li class="comment bypostauthor even">
			       <?php
			       $ad1 = mysqli_query($conn, "select * from adopt where pid = '".$_GET['id']."' ");
 $ad1num = mysqli_num_rows($ad1); 
if($ad1num < 1){ 
?>

			 <a href="../booking/index.php?calendar_id=<?php echo $data['idAnimal'] ;?>"> <button type="submit" name="signup-submit">Adopt Me</button> </a>
			 <?php } else { ?>
			 
			 <button type="submit" name="signup-submit" style="background-color:#CCC;">This Pet Has Been Already Adopted</button> 
			 <?php } ?>
			
			 <?php
			       $ad1 = mysqli_query($conn, "select * from appointment where pid = '".$_GET['id']."' and status = '1' ");
 $ad1num = mysqli_num_rows($ad1); 
if($ad1num < 1){ 
?>

 <a href="bookappointment.php?id=<?php echo $data['idAnimal'] ;?>"> <button type="submit" name="signup-submit">Book Appointment</button> </a>
			
<?php } else { ?>
			 
			 <button type="submit" name="signup-submit" style="background-color:#CCC;">This Pet Has Been Already Booked</button> 
			 <?php } ?>
			 
			 
			 
			 
			</li>
			  
             </ul>

				</p>
			</div>	
		</div>
	</article>
	<h3 id="comments" ></h3>
	
	
</div>


<?php include('includes/footer.php'); ?>