<?php include('header.php'); ?>

<?php
include_once 'includes/dbh.inc.php';
session_start();
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script>
    function clicked() {
    return confirm('Are you sure you want to delete this Animal?');
}</script>
<title>Current Pending Adoptions:</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<h2>Product List</h2>
<table width="100%" border="2" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>#</strong></th>
<th><strong>UID</strong></th>
<th><strong>PID</strong></th>
<th><strong>dcNumber</strong></th>
<th><strong>Name</strong></th>
<th><strong>Phone</strong></th>
<th><strong>Email</strong></th>
<th><strong>Date</strong></th>
<th><strong>Time</strong></th>
<th><strong>Status</strong></th>
</tr>
</thead>
<tbody>
<?php

$count=1;
$id=$_SESSION["id"];
$sel_query="Select * from appointment WHERE uid = $id";

$result = mysqli_query($conn,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["uid"]; ?></td>
<td align="center"><?php echo $row["pid"]; ?></td>
<td align="center"><?php echo $row["dcNumber"]; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["phone"]; ?></td>
<td align="center"><?php echo $row["email"]; ?></td>
<td align="center"><?php echo $row["date"]; ?></td>
<td align="center"><?php echo $row["time"]; ?></td>
<td align="center"><?php echo $row["status"]; ?></td>

</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>