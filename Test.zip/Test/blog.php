<?php
  include 'includes/dbh.inc.php';
  require "header.php";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <?php

      $sql = "SELECT * FROM animals;";
    	$result = mysqli_query($conn, $sql);
    	$resultCheck = mysqli_num_rows($result);

    	if ($resultCheck > 0) {
    		while ($row = mysqli_fetch_assoc($result)) {
    			echo "<br>Animal Number: " . $row['idAnimal'] . "<br>";
                echo "Type: " . $row['Type'] . "<br>";
                echo "Animal's Name: " . $row['Name'] . "<br>";
                echo "Animal's Breed: " . $row['Breed'] . "<br>";
                echo "Animal's Sex: " . $row['Sex'] . "<br>";
                echo "Age: " . $row['Age'] . "<br>";

    		}
    	}
    ?>
  </body>
</html>
