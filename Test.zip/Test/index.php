<?php include('header.php'); ?>
<div id="featured_pets">
	<h3><b>Animal Adoption ArticlesSSSSS</b></h3>
	<div id="featured_inner" class="clearfix">
		<div class="single_pet">
			<a href="pets-single.php" title="Charlie">
				<img width="400" height="200" src="images/pets/dogarticle.jpg" class="attachment-pet_month" alt="Charlie" />
			</a>
			<div class="mask">
				<h2>Dog Adoption Information</h2>
				<p>Everything that you need to know in order to hit the ground running with your new adoption! Techniques, strategies and quality information from trust sources.</p>
				<a href="pets-single.php" title="Charlie" class="more_featured">Search All Articles</a>
			</div>
		</div>
		<div class="single_pet">
			<a href="pets-single.php" title="Shorty">
				<img width="400" height="200" src="images/pets/catarticle.jpg" class="attachment-pet_month" alt="shorty1" />
			</a>
			<div class="mask">
				<h2>Cat Adoption Information</h2>
				<p>Make the adoption process that much easier by reading up and educating yourself on the ins and outs of the adoption process.</p>
				<a href="pets-single.php" title="Shorty" class="more_featured">Search All Articles</a>
			</div>
		</div>
	</div>
</div>
<div id="home_latest_friends" class="clearfix">
	<h2 class="entry-title" id="latest-friends-title">Recently Added Animals:</h2>
	<div id="friends_wrap" class="clearfix">
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/charlie-180x180.jpg" class="attachment-small_pet" alt="Charlie" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/archie1-180x180.jpg" class="attachment-small_pet" alt="Archie" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/mudi-180x180.jpg" class="attachment-small_pet" alt="Mudi" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/chance1-180x180.jpg" class="attachment-small_pet" alt="Chance" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/happy1-180x180.jpg" class="attachment-small_pet" alt="Happy" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/nora1-180x180.jpg" class="attachment-small_pet" alt="Nora" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/inga1-180x180.jpg" class="attachment-small_pet" alt="Inga" />
		</a>
		<a href="pets-single.php" class="single_latest_friend">
			<img width="180" height="180" src="images/pets/ollie-180x180.jpg" class="attachment-small_pet" alt="Ollie" />
		</a>
	</div>
</div>
<section id="home_widgets" align="center">
	<div id="home_widget_wrap" class="banner_widget_count2 rescue_email_banner clearfix" align="center">
			<h1 class="widgettitle" align="center"><b>About Us111</b></h1>
			<h3 class="widgettitle" align="center">Each and every pet listed on Pet Detector is certified and guaranteed to be exactly what you're looking for.
				Any issues? We'll find a better fit for you, no questions asked.
				Simply looking to make the adoption process faster, simpler and easier.</h3>
		
	</div>
</section>
<div class="posts-wrap">
	<section id="home_latest_posts" class="clearfix">
		<h2 class="entry-title" id="latest-posts-title">Real Life Testimonials</h2>
		<article class="first_latest">
			<a href="blog-single.php" title="Meet Charlie">
				<img width="600" height="240" src="images/pets/charlie-600x240.jpg" class="attachment-big_latest" alt="Meet Charlie" />
			</a>
			<h4><a href="blog-single.php" title="Meet Charlie">Meet Charlie</a></h4>
			<div class="meta">
				September 24, 2019
			</div>
			<p>
			</p>
			<a href="blog-single.php" title="Meet Charlie"> </a>
		</article>
		<article class="single_latest">
			<a href="blog-single.php" title="Meet Cindy" class="single_latest_img_link">
				<img width="275" height="110" src="images/pets/cindy1-275x110.jpg" class="attachment-single_latest" alt="Meet Cindy" />
			</a>
			<h4><a href="blog-single.php" title="Meet Cindy">Meet Cindy</a></h4>
			<div class="meta">
				September 24, 2019
			</div>
			<p>
			</p>
			<a href="blog-single.php" title="Meet Cindy"></a>
		</article>
		<article class="single_latest">
			<a href="blog-single.php" title="Meet Chester" class="single_latest_img_link">
				<img width="275" height="110" src="images/pets/chester1-275x110.jpg" class="attachment-single_latest" alt="Meet Chester" />
			</a>
			<h4><a href="blog-single.php" title="Meet Chester">Meet Chester</a></h4>
			<div class="meta">
				September 23, 2019
			</div>
			<p>
			</p>
			<a href="blog-single.php" title="Meet Chester"></a>
		</article>
	</section>
</div>

<?php include('includes/sidebar.php'); ?>
<?php include('includes/footer.php'); ?>