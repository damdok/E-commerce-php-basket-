<?php include('header.php'); ?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Admin Homepage</h2>
		<div class="clearfix">
			<div class="entry-content clearfix">
				<p>
                <form action="adminprodlisting.php">
                    <input type="submit" value="View/Update Product Information" />
                </form>
                <br><br>
                <form action="adminanimal.php">
                    <input type="submit" value="View/Update Animal Information" />
                </form>
                <br><br>
                <form action="../booking/admin/index.php">
                    <input type="submit" value="Scheduling HomePage" />
                </form>
                <br><br>
                <form action="adminsignup.php">
                    <input type="submit" value="Create Special Account Type" />
                </form>
                <br><br>
                <form action="admin/index.php">
                    <input type="submit" value="Adoption Homepage" />
                </form>
				</p><br><br>
				<h2>Items Pending Reviews:</h2>
                
                <form action="adminreview.php">
                    <input type="submit" value="Pending Animal Adoption Posts" />
                </form>
				</p>
				<br><br>
                <form action="productreview.php">
                    <input type="submit" value="Pending Product Posts" />
                </form>
				</p>
			</div>
		</div>


<?php include('includes/footer.php'); ?>