<?php include('header.php'); ?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title></title>
</head>
<p><a href="page-extras.php">D.C. Edit Dashboard</a>
| <a href="includes/logout.inc.php">Logout</a></p>
<body>
<!--Here is a basic example of how to insert data into our database using a simple HTML form-->
<!--Notice that I am using a POST method, and I am sending the data to a script on a separate page-->
<center><form action="includes/insertanimal.inc.php"  method="post" enctype="multipart/form-data">
<h1>Add Animal to Database</h1>
	<input type="text" name="idAnimal" placeholder="Animal's Name ">
	<br><br>
	
	<select name="Type">
				<option value="Dog">Dog</option>
				<option value="Cat">Cat</option>
				<option value="Other">Other</option>
			</select>
	<br><br>
	<input type="text" name="Breed" placeholder="Breed">
	<br><br>
    <select name="Sex">
				<option value="Male">Male</option>
				<option value="Female">Female</option>
			</select>
	<br><br>
    
    <input type="text" name="Color" placeholder="Color">
	<br><br>
    <select name="Size">
				<option value="Small">Small</option>
				<option value="Medium">Medium</option>
				<option value="Large">Large</option>
			</select>
	<br><br>
    <input type="text" name="Description" placeholder="Description">
	<br><br>
	<Text>Date of Birth:   </Text><input type="date" name="DOB" placeholder="Date of Birth">
	<br><br>
    <input type="file" name="image">
    <br><br>
	<input type="submit" name="submit" value="upload"></button>
</form></center>

</body>
</html>
<?php include('footer.php'); ?>