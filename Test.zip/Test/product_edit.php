<?php include('header.php'); ?>

<?php
include_once 'includes/dbh.inc.php';
$id=$_REQUEST['id'];
$query = "SELECT * from pet_products where id='".$id."'"; 
$result = mysqli_query($conn, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Update Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="product_list.php">Product List</a> 
| <a href="product_add.php">Add product to Store</a> 
| <a href="includes/logout.inc.php">Logout</a></p>
<h1>Update Product Information</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$id=$_REQUEST['id'];
$name =$_REQUEST['name'];
$type =$_REQUEST['type'];
$price =$_REQUEST['price'];
$pfor =$_REQUEST['pfor'];
$quantity =$_REQUEST['quantity'];
$update="update pet_products set name='".$name."', type='".$type."', price='".$price."', ForWhich='".$pfor."', quantity='".$quantity."' where id='$id'";
mysqli_query($conn, $update) or die(mysqli_error());
echo ("updated successfully.");
echo ("<meta http-equiv='Refresh' content='1; URL=product_list.php'>");
}else {
?>
<div>
<center><form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="id" type="hidden" value="<?php echo $row['id'];?>" />
<p><input type="text" name="name" placeholder="Enter Name" 
required value="<?php echo $row['name'];?>" /></p>
<p><select name="type">
				<option value="Food">Food</option>
				<option value="Toys">Toys</option>
				<option value="Treats">Treats</option>
				<option value="Caging">Caging</option>
			</select></p>
<p><select name="pfor">
				<option value="dog">Dog</option>
				<option value="cat">Cat</option>
			</select></p>
<p><input type="text" name="price" placeholder="Enter Product Price" 
required value="<?php echo $row['price'];?>" /></p>
<p><input type="text" name="quantity" placeholder="Enter Quantity" 
required value="<?php echo $row['quantity'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form></center>
<?php } ?>
</div>
</div>
</body>
</html>

<?php include('includes/footer.php'); ?>