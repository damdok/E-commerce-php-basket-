<?php
	include_once'header.php';
?>

<div class="posts-wrap">
	<section class="page">
		<h2 class="entry-title">Search Animal</h2>
		<div class="tab-main">
		  <input id="tab1" type="radio" name="tabs" checked="">
		  <label class="tabs" for="tab1"><strong></strong></label>

		 
		  <div class="content">
			<div id="content1">
				<form action="search.php" method="GET">
					<input type="hidden" name="animal" value="dog"/>
					<div class="grid">
						<div class="row">
                        <div class="col">
								Type<label class="custom-select">
									<select class="custom-select" name="type">
										<option value="">Please Select</option>
										<option value="Dog" <?php if($_GET['type'] == 'Dog'){?> selected <?php } ?> >Dog</option>
										<option value="Cat" <?php if($_GET['type'] == 'Cat'){?> selected <?php } ?> >Cat</option>
									</select>
								</label>
							</div>


							<div class="col">
								BREED<label class="custom-select">
									<select class="custom-select" name="breed">
										<option value="" >All</option>	
										<option value="American Curl" <?php if($_GET[''] == 'American Curl'){?> selected <?php } ?> >American Curl</option>
										<option value="Calico" <?php if($_GET['breed'] == 'Calico'){?> selected <?php } ?> >Calico</option>
										<option value="Hound" <?php if($_GET['breed'] == 'Hound'){?> selected <?php } ?> >Hound</option>
										<option value="Poodle" <?php if($_GET['breed'] == 'Poodle'){?> selected <?php } ?> >Poodle</option>
										<option value="Terrier" <?php if($_GET['breed'] == 'Terrier'){?> selected <?php } ?> >Terrier</option>
                                        <option value="Boxer" <?php if($_GET['breed'] == 'Boxer'){?> selected <?php } ?> >Boxer</option>
                                        <option value="Affenpinscher" <?php if($_GET['breed'] == 'Affenpinscher'){?> selected <?php } ?> >Affenpinscher</option> 
										<option value="Akita" <?php if($_GET['breed'] == 'Akita'){?> selected <?php } ?> >Akita</option>
                                        <option value="Beagle" <?php if($_GET['breed'] == 'Beagle'){?> selected <?php } ?> >Beagle</option>
									
									</select>
								</label>
							</div>
							<div class="col">
								SEX<label class="custom-select">
									<select class="custom-select"  name="sex">
										<option value="">All</option>
										<option value="Female" <?php if($_GET['sex'] == 'Female'){?> selected <?php } ?> >Female</option>
										<option value="Male" <?php if($_GET['sex'] == 'Male'){?> selected <?php } ?> >Male</option>
									</select>
								</label>
							</div>
							
						</div>
						<div class="row">
							<div class="col">
								COLOR<label class="custom-select">
									<select class="custom-select" name="color">
										<option value="">All</option>
										<option value="Brown" <?php if($_GET['color'] == 'Brown'){?> selected <?php } ?> >Brown</option>
									
										<option value="Yellow" <?php if($_GET['color'] == 'Yellow'){?> selected <?php } ?> >Yellow</option>
									
										<option value="White" <?php if($_GET['color'] == 'White'){?> selected <?php } ?> >White</option>
										<option value="Black" <?php if($_GET['color'] == 'Black'){?> selected <?php } ?> >Black</option>
									
									</select>
								</label>
							</div>
							<div class="col">
								SIZE<label class="custom-select">
									<select class="custom-select" name="size">
										<option value="">All</option>
										
										
										<option value="Medium" <?php if($_GET['size'] == 'Medium'){?> selected <?php } ?> >Medium</option>
                                        <option value="Small" <?php if($_GET['size'] == 'Small'){?> selected <?php } ?> >Small</option>
										<option value="Large" <?php if($_GET['size'] == 'Large'){?> selected <?php } ?> >Large</option>
									
									</select>
								</label>
							</div>
							<div class="col v-align-btm">
								<button class="grid-btn">Search</button>
							</div>
						</div>
					</div>
				</form>
			</div>
            
			<div id="content2">
				<p>Content for Cat</p>
			</div>

			<div id="content3">
				<p>Content for Pets with special needs</p>
			</div>
		  </div>
		</div>
	</section>



		<div class="posts-wrap">
	<section id="home_latest_posts" class="clearfix">
    <?php 
    $sql = "select * from animals where idAnimal != '' ";
    if($_GET['type'] != ''){  $sql .= " and Type = '".$_GET['type'] ."' ";    }
      if($_GET['breed'] != ''){  $sql .= " and Breed = '".$_GET['breed'] ."' ";    }
      if($_GET['sex'] != ''){  $sql .= " and Sex = '".$_GET['sex'] ."' ";    }
      if($_GET['age'] != ''){  $sql .= " and Age = '".$_GET['age'] ."' ";    }
      if($_GET['color'] != ''){  $sql .= " and Color = '".$_GET['color'] ."' ";    }
      if($_GET['size'] != ''){  $sql .= " and Size = '".$_GET['size'] ."' ";    }
    
  
    
    $query = mysqli_query($conn, $sql);
		
		
		while($data = mysqli_fetch_assoc($query)){ ?>
		
		<article class="single_latest">
			<a href="blog-single.php?id=<?php echo $data['idAnimal']; ?>" title="Meet Cindy" class="single_latest_img_link">
				<img width="275" height="110" src="images/pets/<?php echo $data['img']; ?>" class="attachment-single_latest" alt="Meet Cindy" />
			</a>
			<a href="blog-single.php?id=<?php echo $data['idAnimal']; ?>">	<h2 style="padding:0px;margin:5px;"><?php echo $data['Name']; ?></h2>
            <h4><?php echo $data['Sex']; ?></h4>
            </a>
			
			<p>
			</p>
			</article>
		<?php } ?>
        </section> </div>
	
</div>
<?php 
	include_once('includes/footer.php');
?>


